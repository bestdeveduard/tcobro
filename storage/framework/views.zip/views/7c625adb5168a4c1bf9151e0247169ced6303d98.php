<?php $__env->startSection('title'); ?><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?>

<?php echo e(trans_choice('general.method',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?>

        <?php echo e(trans_choice('general.method',2)); ?></h2>

      <div class="heading-elements">
        <a href="<?php echo e(url('loan/loan_repayment_method/create')); ?>"
          class="btn btn-info btn-sm"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?>

          <?php echo e(trans_choice('general.method',1)); ?></a>
      </div>
    </div>
    <div class="panel-body">
      <table id="order-listing" class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th><?php echo e(trans_choice('general.name',1)); ?></th>
            <th><?php echo e(trans_choice('general.action',1)); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key->id); ?></td>
            <td><?php echo e($key->name); ?></td>
            <td>
              <a href="<?php echo e(url('loan/loan_repayment_method/'.$key->id.'/edit')); ?>"><img
                  src="https://img.icons8.com/cute-clipart/64/000000/edit.png" /></a>
              <a href="<?php echo e(url('loan/loan_repayment_method/'.$key->id.'/delete')); ?>"><img
                  src="https://img.icons8.com/flat_round/64/000000/delete-sign.png" /></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.panel-body -->
  </div>
  <!-- /.box -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>