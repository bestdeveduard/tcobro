
<?php $__env->startSection('title'); ?>
T-Cobro Web | Rutas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title">Reporte de Rutas</h2>

      <div class="heading-elements">
        <a href="<?php echo e(url('loan/loan_product/create')); ?>" class="btn btn-info btn-sm">Agregar ruta</a>
      </div>
    </div>
    <div class="panel-body">
      <table id="order-listing" class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Ruta</th>
            <th>Accion</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key->id); ?></td>
            <td><?php echo e($key->name); ?></td>
            <td>
              <a href="<?php echo e(url('loan/loan_product/'.$key->id.'/edit')); ?>"><img
                  src="https://img.icons8.com/cute-clipart/64/000000/edit.png" /></a>
              <a href="<?php echo e(url('loan/loan_product/'.$key->id.'/delete')); ?>"><img
                  src="https://img.icons8.com/flat_round/64/000000/delete-sign.png" /></a>

            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.panel-body -->
  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>