<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.expense',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title"><?php echo e(trans_choice('general.expense',2)); ?></h2>

      <div class="heading-elements">
        <?php if(Sentinel::hasAccess('expenses.create')): ?>
        <a href="<?php echo e(url('expense/create')); ?>" class="btn btn-info btn-sm"><?php echo e(trans_choice('general.add',1)); ?>

          <?php echo e(trans_choice('general.expense',2)); ?></a>
        <?php endif; ?>
      </div>
    </div>
    <div class="panel-body">
      <div class="table-responsive">
        <table id="order-listing" class="table">
          <thead>
            <tr>
              <th>Categoria</th>
              <th>Montos</th>
              <th>Fecha</th>
              <th>Recurrente</th>
              <th>Descripcion</th>
              <th><?php echo e(trans_choice('general.file',2)); ?></th>
              <th><?php echo e(trans_choice('general.action',1)); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php if(!empty($key->expense_type)): ?>
                <?php echo e($key->expense_type->name); ?>

                <?php endif; ?>
              </td>
              <td><?php echo e($key->amount); ?></td>
              <td><?php echo e($key->date); ?></td>
              <td>
                <?php if($key->recurring==1): ?>
                <?php echo e(trans_choice('general.yes',1)); ?>

                <?php else: ?>
                <?php echo e(trans_choice('general.no',1)); ?>

                <?php endif; ?>
              </td>
              <td><?php echo e($key->notes); ?></td>
              <td>
                <ul class="">
                  <?php $__currentLoopData = unserialize($key->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo asset('uploads/'.$value); ?>" target="_blank"><?php echo $value; ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </td>
              <td>
                <a href="<?php echo e(url('expense/'.$key->id.'/edit')); ?>"><img
                    src="https://img.icons8.com/cute-clipart/64/000000/edit.png" /></a>
                <a href="<?php echo e(url('expense/'.$key->id.'/delete')); ?>"><img
                    src="https://img.icons8.com/flat_round/64/000000/delete-sign.png" /></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    <!-- /.panel-body -->
  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
<script>
$('#order-listing').DataTable({
  "order": [
    [2, "desc"]
  ],
  "columnDefs": [{
    "orderable": false,
    "targets": [6]
  }],
  "language": {
    "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
    "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
    "info": "<?php echo e(trans('general.info')); ?>",
    "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
    "search": "<?php echo e(trans('general.search')); ?>",
    "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
    "paginate": {
      "first": "<?php echo e(trans('general.first')); ?>",
      "last": "<?php echo e(trans('general.last')); ?>",
      "next": "<?php echo e(trans('general.next')); ?>",
      "previous": "<?php echo e(trans('general.previous')); ?>"
    }
  },
  responsive: false
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>