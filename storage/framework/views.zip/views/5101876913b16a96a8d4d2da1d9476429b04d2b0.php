
<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.comment',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?>

        <?php echo e(trans_choice('general.comment',1)); ?></h2>

      <div class="heading-elements">

      </div>
    </div>
    <?php echo Form::open(array('url' => url('loan/'.$id.'/loan_comment/store'), 'method' => 'post', 'class' =>
    'form-horizontal')); ?>

    <div class="panel-body">
      <div class="form-group">
        <?php echo Form::label('notes',trans_choice('general.comment',1),array('class'=>'col-sm-2 control-label')); ?>

        <div class="col-sm-10">
          <?php echo Form::textarea('notes',null, array('class' => 'form-control', 'placeholder'=>"",'required'=>'required')); ?>

        </div>
      </div>
    </div>
    <!-- /.panel-body -->
    <div class="panel-footer">
      <div class="panel-heading">
        <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>
      </div>
    </div>
    <?php echo Form::close(); ?>

  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>