
<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.other_income',1)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.other_income',1)); ?></h2>

      <div class="heading-elements">

      </div>
    </div>
    <?php echo Form::open(array('url' => url('other_income/store'), 'method' => 'post','class'=>'', 'name' =>
    'form',"enctype"=>"multipart/form-data")); ?>

    <div class="panel-body">

      <div class="form-group">
        <?php echo Form::label('other_income_type_id',trans_choice('general.income',1).'
        '.trans_choice('general.type',1),array('class'=>' control-label')); ?>


        <?php echo Form::select('other_income_type_id',$types,null, array('class' => 'form-control','required'=>'required')); ?>


      </div>
      <div class="form-group">
        <?php echo Form::label('amount',trans_choice('general.income',1).'
        '.trans_choice('general.amount',1),array('class'=>'')); ?>

        <?php echo Form::text('amount',null, array('class' => 'form-control touchspin',
        'placeholder'=>"",'required'=>'required')); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('account_id',trans_choice('general.account',1).' '.trans_choice('general.to',1),array('class'=>'
        control-label')); ?>

        <?php echo Form::select('account_id',$chart_assets,null, array('class' => 'form-control
        select2','placeholder'=>"",'required'=>'required')); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('date',trans_choice('general.date',1),array('class'=>'')); ?>

        <?php echo Form::text('date',null, array('class' => 'form-control date-picker',
        'placeholder'=>"",'required'=>'required')); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('notes',trans_choice('general.description',1),array('class'=>'')); ?>

        <?php echo Form::textarea('notes',null, array('class' => 'form-control','rows'=>'3')); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('files',trans_choice('general.file',2).'('.trans_choice('general.borrower_file_types',1).')',array('class'=>'')); ?>

        <?php echo Form::file('files[]', array('class' => 'form-control', 'multiple'=>"",'rows'=>'3')); ?>


      </div>
      <p class="bg-navy disabled color-palette"><?php echo e(trans_choice('general.custom_field',2)); ?></p>
      <?php $__currentLoopData = $custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="form-group">
        <?php echo Form::label($key->id,$key->name,array('class'=>'')); ?>

        <?php if($key->field_type=="number"): ?>
        <input type="number" class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
        <?php if($key->field_type=="textfield"): ?>
        <input type="text" class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
        <?php if($key->field_type=="date"): ?>
        <input type="text" class="form-control date-picker" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
        <?php if($key->field_type=="textarea"): ?>
        <textarea class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>></textarea>
        <?php endif; ?>
        <?php if($key->field_type=="decimal"): ?>
        <input type="text" class="form-control touchspin" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

    <div class="panel-footer">
      <div class="heading-elements">
        <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>
      </div>
    </div>
    <?php echo Form::close(); ?>

    <!-- /.panel-body -->
  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
<script>
$(document).ready(function(e) {

})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>