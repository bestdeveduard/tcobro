<?php $__env->startSection('title'); ?>
T-Cobro Web | Editar Cliente
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h3 class="panel-title "><?php echo e(trans_choice('general.edit',1)); ?> <?php echo e(trans_choice('general.borrower',1)); ?></h3>
      <div class="heading-elements">

      </div>
    </div>
    <?php echo Form::open(array('url' => url('borrower/'.$borrower->id.'/update'), 'method' => 'post', 'name' =>
    'form',"enctype"=>"multipart/form-data")); ?>

    <div class="panel-body">
      <div class="form-group">
        <p class="card-description">
        <h5 style="color:#46b979;">Datos personales</h5>
        </p>
        <input type="hidden" name="title" id="title" value="Mr"></input>
        <input type="hidden" name="gender" id="gender" value="male"></input>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label" align="right"><?php echo e(trans_choice('general.first_name',1)); ?> *</label>
              <div class="col-sm-9">
                <?php echo Form::text('first_name',$borrower->first_name, array('class' => 'form-control',
                'placeholder'=>trans_choice('general.first_name',1),'required'=>'required')); ?>

              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label" align="right"><?php echo e(trans_choice('general.last_name',1)); ?> *</label>
              <div class="col-sm-9">
                <?php echo Form::text('last_name',$borrower->last_name, array('class' => 'form-control',
                'placeholder'=>trans_choice('general.last_name',1),'required'=>'required')); ?>

              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group row">
              <label class="col-sm-4 col-form-label" align="right">ID/Pasaporte</label>
              <div class="col-sm-8">
                <?php echo Form::text('unique_number',$borrower->unique_number, array('class' =>'form-control',
                'placeholder'=>trans_choice('general.unique_number',1),'required'=>'required')); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
      <p class="card-description">
      <h5 style="color:#46b979;">Datos de contacto</h5>
      </p>
      <div class="form-group">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Direccion *</label>
              <div class="col-sm-8">
                <?php echo Form::text('address',$borrower->address, array('class' => 'form-control', 'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label"><?php echo e(trans_choice('general.country',1)); ?></label>
              <div class="col-sm-9">
                <?php echo Form::select('country_id',$countries,$borrower->country_id,array('class'=>'form-control
                select2','placeholder'=>'','required'=>'required')); ?>

              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Telefono movil *</label>
              <div class="col-sm-8">
                <?php echo Form::text('mobile',$borrower->mobile, array('class' => 'form-control',
                'placeholder'=>trans_choice('general.numbers_only',1))); ?>

              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Telefono fijo</label>
              <div class="col-sm-9">
                <?php echo Form::text('phone',$borrower->phone, array('class' => 'form-control', 'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Email</label>
              <div class="col-sm-8">
                <?php echo Form::text('email',$borrower->email, array('class' => 'form-control',
                'placeholder'=>trans_choice('general.email',1))); ?>

              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Geolocalizacion:</label>
              <div class="col-sm-2">
                <a class="btn btn-secondary" onclick="showMap()">Mapa</a>
              </div>
              <div class="col-sm-7">
                <div id="map-canvas" style="display: none; width: 100%; height: 130px;" data-lat="none" data-lng="none" data-zoom="16"
                  data-style="6"></div>
                  <input type="hidden" id="geolocation" name="geolocation"></input>
              </div>
            </div>
          </div>
        </div>
      </div>

      <p class="card-description">
      <h5 style="color:#46b979;">Informacion Laboral</h5>
      </p>
      <div class="form-group">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label"><?php echo e(trans_choice('general.business',1)); ?></label>
              <div class="col-sm-8">
                <?php echo Form::text('business_name',$borrower->business_name, array('class' => 'form-control',
                'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label"><?php echo e(trans_choice('Telefono Empresa',1)); ?></label>
              <div class="col-sm-9">
                <?php echo Form::text('phone_business',$borrower->phone_business, array('class' => 'form-control',
                'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label"><?php echo e(trans_choice('general.working_status',1)); ?></label>
              <div class="col-sm-8">
                <?php echo Form::select('working_status',array('Employee'=>trans_choice('general.Employee',1),'Owner'=>trans_choice('general.Owner',1),'Student'=>trans_choice('general.Student',1),'Overseas
                Worker'=>trans_choice('general.Overseas
                Worker',1),'Pensioner'=>trans_choice('general.Pensioner',1),'Unemployed'=>trans_choice('general.Unemployed',1)),$borrower->working_status,
                array('class' => 'form-control',)); ?>

              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Tiempo laborando</label>
              <div class="col-sm-9">
                <?php echo Form::text('working_time',$borrower->working_time, array('class' => 'form-control',
                'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Ingresos $</label>
              <div class="col-sm-8">
                <?php echo Form::number('ingresos',$borrower->ingresos, array('class' => 'form-control', 'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
        </div>
      </div>

      <p class="card-description">
      <h5 style="color:#46b979;">Informacion codeudor</h5>
      </p>
      <div class="form-group">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Referencias</label>
              <div class="col-sm-8">
                <?php echo Form::text('referencia_1',$borrower->referencia_1, array('class' => 'form-control',
                'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label">Telefono</label>
              <div class="col-sm-9">
                <?php echo Form::text('company_phone',$borrower->company_phone, array('class' => 'form-control',
                'placeholder'=>"")); ?>

              </div>
            </div>
          </div>
        </div>
      </div>

      <p class="card-description">
      <h5 style="color:#46b979;">Archivos</h5>
      </p>
      <div class="form-group">
        <label>Adjuntar imagen</label>
        <div class="input-group col-xs-12">
          <?php if(!empty($borrower->photo)): ?>
          <a class="fancybox" rel="group" href="<?php echo e(url(asset('uploads/'.$borrower->photo))); ?>"> <img
              src="<?php echo e(url(asset('uploads/'.$borrower->photo))); ?>" width="120" /></a>
          <?php else: ?>
          <input type="text" class="form-control file-upload-info" style="border-bottom-style: solid;" disabled
            placeholder="Cargar documento">
          <?php endif; ?>

          <span class="input-group-append">
            <button class="file-upload-browse btn btn-primary" type="button">Subir</button>
            <input type="file" name="photo" class="file-upload-default"
              style="visibility: visible; position: absolute; z-index: 2; opacity: 0; height: 45px; width: 90px;">
          </span>
        </div>
      </div>
      <div class="form-group">
        <label>Adjuntar Documentos</label>
        <div class="input-group col-xs-12">
          <?php $__currentLoopData = unserialize($borrower->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <span id="file_<?php echo e($key); ?>_span">

            <a href="<?php echo asset('uploads/'.$value); ?>" target="_blank">
              <!---<?php echo $value; ?>--->Visualizar
            </a>
            <button value="<?php echo e($key); ?>" id="<?php echo e($key); ?>" onclick="delete_file(this)" type="button"
              class="btn btn-danger btn-xs">
              <i class="fa fa-trash"></i></button>
          </span><br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <input type="text" class="form-control file-upload-info" style="border-bottom-style: solid;" disabled
            placeholder="Cargar documento">
          <span class="input-group-append">
            <button class="file-upload-browse btn btn-primary" type="button">Subir</button>
            <input type="file" name="files[]" class="file-upload-default"
              style="visibility: visible; position: absolute; z-index: 2; opacity: 0; height: 45px; width: 90px;">
          </span>
        </div>
      </div>
      <div class="form-group">
        <label for="exampleTextarea1">Notas</label>
        <?php echo Form::textarea('notes',$borrower->notes, array('class' => 'form-control', 'placeholder'=>"",'rows'=>'3')); ?>

      </div>

      <div class="form-group" style="display: none;">
        <div class="row">
          <div class="col-md-4">
            <?php echo Form::label('whatsapp_enabled',trans('Envio mensajes Whatsapp'),array('class'=>'control-label')); ?>

            <?php echo Form::select('whatsapp_enabled',array('0'=>trans('general.no'), '1'=>trans('general.yes')),
            $borrower->whatsapp_enabled, array('class'=>'form-control','required'=>'required')); ?>

          </div>
        </div>
      </div>

      <p style="display: none;" class="bg-navy disabled color-palette"><?php echo e(trans_choice('general.login',1)); ?>

        <?php echo e(trans_choice('general.detail',2)); ?></p>
      <div style="display: none;" class="form-group">
        <div class="row">
          <div class="col-md-4">
            <?php echo Form::label('username',trans_choice('general.username',1),array('class'=>'')); ?>

            <?php echo Form::text('username',$borrower->username, array('class' => 'form-control', 'placeholder'=>"")); ?>

          </div>
          <div class="col-md-4">
            <?php echo Form::label('password',trans_choice('general.password',1),array('class'=>'')); ?>

            <?php echo Form::password('password', array('class' => 'form-control', 'placeholder'=>"")); ?>

          </div>
          <div class="col-md-4">
            <?php echo Form::label('repeatpassword',trans_choice('general.repeat_password',1),array('class'=>'')); ?>

            <?php echo Form::password('repeatpassword', array('class' => 'form-control', 'placeholder'=>"")); ?>

          </div>
        </div>
      </div>
      <div class="form-group" style="display: none;">
        <?php echo Form::label('loan_officers',trans_choice('general.loan_officer_access',2),array('class'=>'')); ?>

        <?php echo Form::select('loan_officers[]',$user,null, array('class' => 'form-control select2','multiple'=>'')); ?>

      </div>
      <p style="display: none;" class="bg-navy disabled color-palette"><?php echo e(trans_choice('general.custom_field',2)); ?></p>
      <?php $__currentLoopData = $custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="form-group">
        <?php echo Form::label($key->id,$key->name,array('class'=>'')); ?>

        <?php if($key->field_type=="number"): ?>
        <input type="number" class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required
        <?php endif; ?>
        value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first()->name); ?>

        <?php endif; ?>">
        <?php endif; ?>
        <?php if($key->field_type=="textfield"): ?>
        <input type="text" class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required
        <?php endif; ?>
        value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first()->name); ?>

        <?php endif; ?>">
        <?php endif; ?>
        <?php if($key->field_type=="date"): ?>
        <input type="text" class="form-control date-picker" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required
        <?php endif; ?>
        value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first()->name); ?>

        <?php endif; ?>">
        <?php endif; ?>
        <?php if($key->field_type=="textarea"): ?>
        <textarea class="form-control" name="<?php echo e($key->id); ?>"
          <?php if($key->required==1): ?> required <?php endif; ?>><?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first()->name); ?> <?php endif; ?></textarea>
        <?php endif; ?>
        <?php if($key->field_type=="decimal"): ?>
        <input type="text" class="form-control touchspin" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required
        <?php endif; ?>
        value="<?php if(!empty(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first())): ?><?php echo e(\App\Models\CustomFieldMeta::where('custom_field_id',$key->id)->where('parent_id',$borrower->id)->where('category','borrowers')->first()->name); ?>

        <?php endif; ?>">
        <?php endif; ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- /.panel-body -->
    <div class="panel-footer">
      <div>
        <button type="submit" class="btn btn-info pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>

        <a class="btn btn-secondary" href="<?php echo e(url('borrower/data')); ?>">Cancelar</a>
      </div>
    </div>
    <?php echo Form::close(); ?>

  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script>
function delete_file(e) {
  var id = e.id;
  swal({
    title: 'Are you sure?',
    text: '',
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Ok',
    cancelButtonText: 'Cancel'
  }).then(function() {
    $.ajax({
      type: 'GET',
      url: "<?php echo url('borrower/'.$borrower->id); ?>/delete_file?id=" + id,
      success: function(data) {
        $("#file_" + id + "_span").remove();
        swal({
          title: 'Deleted',
          text: 'File successfully deleted',
          type: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ok',
          timer: 2000
        })
      }
    });
  })

}
</script>
<script src="<?php echo e(asset('assets/themes/limitless/js/borrower_map.js')); ?>"></script>
<script type="text/javascript">
  $(document).ready(function () {
    var geolocation = "<?php echo $borrower->geolocation; ?>";
    var latlng = geolocation.split(",");
    $('#map-canvas').attr("data-lat", latlng[0]);
	  $('#map-canvas').attr("data-lng", latlng[1]);
  });

  function showMap() {
    $('#map-canvas').css('display', 'block');
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>