<?php $__env->startSection('title'); ?>
Collectors
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">

    <?php if(Session::has('flash_notification.message')): ?>
    <script>
    toastr. {
      {
        Session::get('flash_notification.level')
      }
    }('<?php echo e(Session::get("flash_notification.message")); ?>', 'Response Status')
    </script>
    <?php endif; ?>
    <?php if(isset($msg)): ?>
    <div class="alert alert-success">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <?php echo e($msg); ?>

    </div>
    <?php endif; ?>
    <?php if(isset($error)): ?>
    <div class="alert alert-error">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <?php echo e($error); ?>

    </div>
    <?php endif; ?>
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <div class="panel-heading">
      <h2 class="panel-title">Reports collector user</h2>

      <div class="heading-elements">
        <a href="<?php echo e(url('user/collector/create')); ?>" class="btn btn-info btn-xs">
          Add Collector
        </a>
      </div>
    </div>

    <div class="row">
      <div class="col-12">
        <div class="table-responsive">
          <table id="order-listing" class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Member ID</th>
                <th>Collector name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Condition</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $num = 1;
               ?>

              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($num); ?></td>
                <td><?php echo e($key->business_id); ?></td>
                <td><?php echo e($key->first_name); ?> <?php echo e($key->last_name); ?></td>
                <td><?php echo e($key->email); ?></td>
                <td><?php echo e($key->phone); ?></td>
                <td>Secondary</td>
                <td>
                  <a href="<?php echo e(url('user/collector/'.$key->id.'/role')); ?>"><img
                      src="https://img.icons8.com/dusk/64/000000/admin-settings-male.png" /></a>
                  <a href="<?php echo e(url('user/collector/'.$key->id.'/edit')); ?>"><img
                      src="https://img.icons8.com/cute-clipart/64/000000/edit.png" /></a>
                  <a id="deleteProductId" plan_id="<?php echo e($key->id); ?>"><img
                      src="https://img.icons8.com/flat_round/64/000000/delete-sign.png" /></a>
                </td>
              </tr>
              <?php 
              $num++;
               ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="deleteproductmodal" tabindex="-1" role="dialog" aria-labelledby="deleteProductModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="deleteProductModalLabel">Delete Collector</h4>
      </div>
      <?php echo Form::open(array('url' =>url('user/collector/delete'), 'name'=>'deleteProduct', 'id'=>'deleteProduct',
      'method'=>'post', 'class' => 'form-horizontal', 'enctype'=>'multipart/form-data')); ?>

      <?php echo Form::hidden('action', 'delete', array('class'=>'form-control')); ?>

      <?php echo Form::hidden('user_id', '', array('class'=>'form-control', 'id'=>'user_id')); ?>

      <div class="modal-body">
        <center>
          <h5>Are you sure to delete this collector?</h5>
        </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary" id="deleteProduct">Delete</button>
      </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<script type="text/javascript">
$(document).on('click', '#deleteProductId', function() {
  var plan_id = $(this).attr('plan_id');
  $('#user_id').val(plan_id);
  $("#deleteproductmodal").modal('show');
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>