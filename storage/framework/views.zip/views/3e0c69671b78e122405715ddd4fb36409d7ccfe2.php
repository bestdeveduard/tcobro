<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.role',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel panel-white">
        <div class="panel-heading">
            <h6 class="panel-title"><?php echo e(trans_choice('general.role',2)); ?></h6>

            <div class="heading-elements">
                <a href="<?php echo e(url('user/role/create')); ?>" class="btn btn-info btn-xs">
                    <?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.role',1)); ?>

                </a>
            </div>
        </div>
        <div class="panel-body">
            <table class="table responsive table-bordered table-hover table-stripped" id="">
                <thead>
                <tr>
                    <th><?php echo e(trans_choice('general.name',1)); ?></th>
                    <th><?php echo e(trans('general.slug')); ?></th>
                    <th><?php echo e(trans_choice('general.action',1)); ?></th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key->name); ?></td>
                        <td><?php echo e($key->slug); ?></td>
                        <td>
                            <ul class="icons-list">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right">
                                        <li>
                                            <a href="<?php echo e(url('user/role/'.$key->id.'/edit')); ?>"><i
                                                        class="fa fa-edit"></i>
                                                <?php echo e(trans('general.edit')); ?></a>
                                        </li>
                                        <?php if($key->id!=1): ?>
                                            <li>
                                                <a href="<?php echo e(url('user/role/'.$key->id.'/delete')); ?>"
                                                   class="delete"><i
                                                            class="fa fa-trash"></i>
                                                    <?php echo e(trans('general.delete')); ?></a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>