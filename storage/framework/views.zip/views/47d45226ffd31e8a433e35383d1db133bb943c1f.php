<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.permission',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="panel panel-white">
        <div class="panel-heading">
            <h6 class="panel-title"><?php echo e(trans_choice('general.permission',2)); ?></h6>

            <div class="heading-elements">
                <a href="<?php echo e(url('user/permission/create')); ?>" class="btn btn-info btn-xs">
                    <i class="fa fa-plus"></i>
                </a>
            </div>
        </div>
        <div class="panel-body">
            <table class="table   table-hover table-striped" id="">
                <thead>
                <tr>
                    <th><?php echo e(trans('general.name')); ?></th>
                    <th><?php echo e(trans('general.parent')); ?></th>
                    <th><?php echo e(trans('general.slug')); ?></th>
                    <th><?php echo e(trans('general.action')); ?></th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($key->parent_id!=0): ?>
                                |___
                            <?php endif; ?>
                            <?php echo e($key->name); ?>

                        </td>
                        <td>
                            <?php if(count($key->parent)>0): ?>
                                <?php echo e($key->parent->name); ?>

                            <?php else: ?>
                                <?php echo e(trans('general.no_parent')); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($key->slug); ?></td>
                        <td>
                            <ul class="icons-list">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right">
                                        <li>
                                            <a href="<?php echo e(url('user/permission/'.$key->id.'/edit')); ?>"><i
                                                        class="fa fa-edit"></i>
                                                <?php echo e(trans('general.edit')); ?></a>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(url('user/permission/'.$key->id.'/delete')); ?>"
                                               data-toggle="confirmation"><i
                                                        class="fa fa-trash"></i>
                                                <?php echo e(trans('general.delete')); ?></a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

    <script>
        $('#data-table').DataTable({
            "language": {
                "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
                "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
                "info": "<?php echo e(trans('general.info')); ?>",
                "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
                "search": "<?php echo e(trans('general.search')); ?>",
                "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
                "paginate": {
                    "first": "<?php echo e(trans('general.first')); ?>",
                    "last": "<?php echo e(trans('general.last')); ?>",
                    "next": "<?php echo e(trans('general.next')); ?>",
                    "previous": "<?php echo e(trans('general.previous')); ?>"
                },
                "columnDefs": [
                    {"orderable": false, "targets": 0}
                ]
            },
            responsive: true,
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>