
<?php $__env->startSection('title'); ?><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.transaction',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel panel-white">
        <div class="panel-heading">
            <h6 class="panel-title"><?php echo e(trans_choice('general.loan',1)); ?> <?php echo e(trans_choice('general.transaction',1)); ?></h6>

            <div class="heading-elements">

            </div>
        </div>
        <div class="panel-body">
            <div class="col-md-6">
                <table class="table table-striped table-hover">
                    <tr>
                        <td><?php echo e(trans_choice('general.id',1)); ?></td>
                        <td><?php echo e($loan_transaction->id); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(trans_choice('general.type',1)); ?></td>
                        <td>
                            <?php if($loan_transaction->transaction_type=='disbursement'): ?>
                                <?php echo e(trans_choice('general.disbursement',1)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='specified_due_date'): ?>
                                <?php echo e(trans_choice('general.specified_due_date',2)); ?>   <?php echo e(trans_choice('general.fee',1)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='installment_fee'): ?>
                                <?php echo e(trans_choice('general.installment_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='overdue_installment_fee'): ?>
                                <?php echo e(trans_choice('general.overdue_installment_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='loan_rescheduling_fee'): ?>
                                <?php echo e(trans_choice('general.loan_rescheduling_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='overdue_maturity'): ?>
                                <?php echo e(trans_choice('general.overdue_maturity',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='disbursement_fee'): ?>
                                <?php echo e(trans_choice('general.disbursement',1)); ?> <?php echo e(trans_choice('general.charge',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='interest'): ?>
                                <?php echo e(trans_choice('general.interest',1)); ?> <?php echo e(trans_choice('general.applied',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='repayment'): ?>
                                <?php echo e(trans_choice('general.repayment',1)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='write_off_recovery'): ?>
                                <?php echo e(trans_choice('general.recovery',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='penalty'): ?>
                                <?php echo e(trans_choice('general.penalty',1)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='interest_waiver'): ?>
                                <?php echo e(trans_choice('general.interest',1)); ?> <?php echo e(trans_choice('general.waiver',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='charge_waiver'): ?>
                                <?php echo e(trans_choice('general.charge',1)); ?>  <?php echo e(trans_choice('general.waiver',2)); ?>

                            <?php endif; ?>
                            <?php if($loan_transaction->transaction_type=='write_off'): ?>
                                <?php echo e(trans_choice('general.write_off',1)); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><?php echo e(trans_choice('general.date',1)); ?></td>
                        <td><?php echo e($loan_transaction->date); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(trans_choice('general.amount',1)); ?></td>
                        <td>
                            <?php if($loan_transaction->credit>$loan_transaction->debit): ?>
                                <?php echo e(number_format($loan_transaction->credit,2)); ?>

                            <?php else: ?>
                                <?php echo e(number_format($loan_transaction->debit,2)); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php if(!empty($loan_transaction->receipt)): ?>
                        <tr>
                            <td><?php echo e(trans_choice('general.receipt',1)); ?></td>
                            <td>
                                <?php echo e($loan_transaction->receipt); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td><?php echo e(trans_choice('general.note',2)); ?></td>
                        <td>
                            <?php echo e($loan_transaction->notes); ?>

                        </td>
                    </tr>
                    <?php $__currentLoopData = $custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($key->custom_field)): ?>
                            <tr>
                                <td>
                                    <?php echo e($key->custom_field->name); ?>

                                </td>
                                <td><?php echo e($key->name); ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        <!-- /.panel-body -->
        <div class="panel-footer">
            <div class="heading-elements">
                <a href="<?php echo e(url()->previous()); ?>"  class="btn btn-primary pull-right"><?php echo e(trans_choice('general.back',1)); ?></a>
            </div>
        </div>
    </div>
    <!-- /.box -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>