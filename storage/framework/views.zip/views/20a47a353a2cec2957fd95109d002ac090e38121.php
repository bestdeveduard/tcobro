<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.cash_flow',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title">
        <?php echo e(trans_choice('general.cash_flow',1)); ?>

        <?php if(!empty($start_date)): ?>
        for period: <b><?php echo e($start_date); ?> to <?php echo e($end_date); ?></b>
        <?php endif; ?>
      </h2>

      <div class="heading-elements">
        <button class="btn btn-sm btn-info hidden-print" onclick="window.print()">Print</button>
      </div>
    </div>
    <div class="panel-body hidden-print">
      <h4 class=""><?php echo e(trans_choice('general.date',1)); ?> <?php echo e(trans_choice('general.range',1)); ?></h4>
      <?php echo Form::open(array('url' => Request::url(), 'method' => 'post','class'=>'form-horizontal', 'name' => 'form')); ?>

      <div class="row">
        <div class="col-md-2">
          <?php echo Form::date('start_date',null, array('class' => 'form-control date-picker', 'placeholder'=>"From
          Date",'required'=>'required')); ?>

        </div>
        <div class="col-md-1  text-center" style="padding-top: 15px;">
          to
        </div>
        <div class="col-md-2">
          <?php echo Form::date('end_date',null, array('class' => 'form-control date-picker', 'placeholder'=>"To
          Date",'required'=>'required')); ?>

        </div>
      </div>
      <br>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success"><?php echo e(trans_choice('general.search',1)); ?>!
            </button>

            <a href="<?php echo e(Request::url()); ?>" class="btn btn-danger"><?php echo e(trans_choice('general.reset',1)); ?>!</a>            
          </div>
        </div>
      </div>
      <?php echo Form::close(); ?>


    </div>
    <!-- /.panel-body -->

  </div>
  <!-- /.box -->
  
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>