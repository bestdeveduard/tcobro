<?php $__env->startSection('title'); ?>
    <?php echo e(trans_choice('general.user',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <p align="right"><a href="<?php echo e(url('super_admin/addadmin')); ?>" type="button" class="btn btn-primary mr-2">Crear Admin</a></p>
  <?php
    $active = 0;
    $inactive = 0;
    foreach($data as $key) {
      if ($key->active_status == 1) {
        $active++;
      } else if ($key->active_status == 2) {
        $inactive++;
      }
    }
  ?>
  <div class="row">
    <div class="col-md-3 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <div class="d-flex justify-content-around align-items-center">
            <div class="icon-rounded-primary">
              <i class="fas fa-users"></i>
            </div>
            <div>
              <center><h5>Usuarios activos</h5></center>
              <center><h5 class="mb-0"><?php echo e($active); ?></h5></center>  
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <div class="d-flex justify-content-around align-items-center">
            <div class="icon-rounded-primary">
              <i class="fas fa-users"></i>
            </div>
            <div>
              <center><h5>Usuarios inactivos</h5></center>
              <center><h5 class="mb-0"><?php echo e($inactive); ?></h5></center>            
            </div>
          </div>
        </div>
      </div>
    </div>  
    <!-- <div class="col-md-3 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <div class="d-flex justify-content-around align-items-center">
            <div class="icon-rounded-primary">
              <i class="fas fa-users"></i>
            </div>
            <div>                
              <center><h5>Usuarios vencidos</h5></center>
              <center><h5 class="mb-0">0</h5></center>           
            </div>
          </div>
        </div>
      </div>
    </div> -->
  </div>

  <div class="card">
    <div class="card-body">
      <h2>Reporte de control</h2>
      <br>
      <br>
      <div class="row">
        <div class="col-12">
          <div class="table-responsive">
            <table id="order-listing" class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Member ID</th>
                  <th>Customer</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Country</th>
                  <th>Condition</th>
                  <th>Plan</th>
                  <th>Expiration</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>                
                <?php 
                  $num = 1;
                 ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($num); ?></td>
                  <td><?php echo e($key->id); ?></td>
                  <td><?php echo e($key->first_name); ?> <?php echo e($key->last_name); ?></td>
                  <td><?php echo e($key->email); ?></td>
                  <td><?php echo e($key->phone); ?></td>
                  <td><?php echo e($key->country_name); ?></td>
                  <td>
                    <?php if(Sentinel::inRole('2')): ?>
                    Primary
                    <?php elseif(Sentinel::inRole('3')): ?>
                    Secondary
                    <?php endif; ?>
                  </td>
                  <td><?php echo e($key->plan_id); ?></td>
                  <td><?php echo e($key->plan_expired_date); ?></td>
                  <td>
                    <?php if($key->active_status == 1): ?>
                      <label style="width: 100px;"  class="badge badge-success">Activado</label>
                    <?php elseif($key->active_status == 2): ?>
                      <label style="width: 100px;"  class="badge badge-secondary">Inactivo</label>
                    <?php else: ?>
                      <label style="width: 100px;"  class="badge badge-danger">Vencido</label>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if($key->active_status == 1): ?>
                      <a href="<?php echo e(url('super_admin/'.$key->id.'/deactive')); ?>" class="btn btn-outline-primary">Desactivar</a>
                    <?php elseif($key->active_status == 2): ?>
                      <a href="<?php echo e(url('super_admin/'.$key->id.'/active')); ?>" class="btn btn-outline-success">Activar</a>
                    <?php else: ?>
                      <a href="<?php echo e(url('super_admin/'.$key->id.'/active')); ?>" class="btn btn-outline-success">Renovar</a>
                    <?php endif; ?>
                    
                    <a href="<?php echo e(url('super_admin/'.$key->id.'/delete')); ?>" class="btn btn-outline-danger delete">Delete</a>                      
                  </td>                  
                </tr>
                <?php 
                  $num++;
                 ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>