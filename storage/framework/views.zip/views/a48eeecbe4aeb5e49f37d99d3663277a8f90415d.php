<?php $__env->startSection('title'); ?><?php echo e(trans_choice('general.journal',1)); ?> <?php echo e(trans_choice('general.manual_entry',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h3 class="panel-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.journal',1)); ?>

        <?php echo e(trans_choice('general.manual_entry',1)); ?></h3>

      <div class="heading-elements">
      </div>
    </div>
    <?php echo Form::open(array('url' => url('accounting/manual_entry/store'), 'method' => 'post', 'class' =>
    'form-horizontal')); ?>

    <div class="panel-body">

      <div class="form-group">
        <?php echo Form::label('amount',trans_choice('general.amount',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::text('amount',null, array('class' => 'form-control touchspin', 'placeholder'=>"Ingrese el monto del
          pago sin comas",'required'=>'required')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('date',trans_choice('general.date',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::text('date',date("Y-m-d"), array('class' => 'form-control date-picker',
          'placeholder'=>"",'required'=>'required')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('credit_account_id',trans_choice('general.credit',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::select('credit_account_id',$chart_of_accounts,null, array('class' => 'form-control select2',
          'placeholder'=>"",'required'=>'')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('debit_account_id',trans_choice('general.debit',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::select('debit_account_id',$chart_of_accounts,null, array('class' => 'form-control select2',
          'placeholder'=>"",'required'=>'')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('reference',trans_choice('general.reference',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-9">
          <?php echo Form::text('reference',null, array('class' => 'form-control', 'rows'=>"2")); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('name',trans_choice('general.description',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-9">
          <?php echo Form::textarea('name',null, array('class' => 'form-control', 'rows'=>"2")); ?>

        </div>
      </div>

    </div>
    <!-- /.panel-body -->
    <div class="panel-footer">
      <div class="heading-elements">
        <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>
      </div>
    </div>
    <?php echo Form::close(); ?>

  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>