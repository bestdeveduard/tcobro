
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('general.add')); ?> <?php echo e(trans_choice('general.role',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel panel-white">
        <div class="panel-heading">
            <h6 class="panel-title"><?php echo e(trans('general.add')); ?> <?php echo e(trans_choice('general.role',1)); ?></h6>

        </div>
        <?php echo Form::open(array('url' => 'user/role/store','class'=>'',"enctype" => "multipart/form-data")); ?>

        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="form-line">
                            <?php echo Form::label(trans_choice('general.name',1) ,null,array('class'=>'control-label')); ?>

                            <?php echo Form::text('name',null,array('class'=>'form-control')); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <hr>
                        <h4><?php echo e(trans_choice('general.manage',1)); ?> <?php echo e(trans_choice('general.permission',2)); ?></h4>

                        <div class="col-md-6">
                            <table class="table table-stripped table-hover">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($permission->parent_id==0): ?>
                                                <strong><?php echo e($permission->name); ?></strong>
                                            <?php else: ?>
                                                <?php echo e($permission->name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(!empty($permission->description)): ?>
                                                <i class="fa fa-info" data-toggle="tooltip"
                                                   data-original-title="<?php echo e($permission->description); ?>"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <input type="checkbox" data-parent="<?php echo e($permission->parent_id); ?>"
                                                   name="permission[]" value="<?php echo e($permission->slug); ?>"
                                                   id="<?php echo e($permission->id); ?>"
                                                   class="styled pcheck">
                                            <label class="" for="<?php echo e($permission->id); ?>">

                                            </label>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- /.panel-body -->
        <div class="panel-footer">
            <div class="heading-elements">
                <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
    <script>
        $(document).ready(function () {
            $(".pcheck").on('click', function (e) {
                if($(this).is(":checked")) {
                    if ($(this).attr('data-parent') == 0) {
                        var id = $(this).attr('id');
                        $(":checkbox[data-parent=" + id + "]").attr('checked','checked');

                    }
                }else{
                    if ($(this).attr('data-parent') == 0) {
                        var id = $(this).attr('id');
                        $(":checkbox[data-parent=" + id + "]").removeAttr('checked');

                    }
                }
                $.uniform.update();
            });

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>