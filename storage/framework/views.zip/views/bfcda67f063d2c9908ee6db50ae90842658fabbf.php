
<?php $__env->startSection('title'); ?>
T-Cobro Web | GPS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card panel panel-white" style="background: white;">
  <div class="card-body">
    <div class="panel-body hidden-print">
      <?php echo Form::open(array('url' => Request::url(), 'method' => 'post','class'=>'form-horizontal', 'name' => 'form')); ?>

      <div class="row">
        <div class="col-md-2">
          <?php echo Form::label('end_date', trans_choice('general.search',1).'
          '.trans_choice('general.date',1),array('class'=>'')); ?>

          <?php echo Form::date('end_date', $end_date, array('class' => 'form-control date-picker',
          'placeholder'=>"",'required'=>'required')); ?>

        </div>

        <div class="col-md-2">
          <label for="name">Usuario:</label>
          <div>
            <?php if(count($users_list) > 0): ?>
            <select name="user_id" id="user_id" class="form-control">
              <?php $__currentLoopData = $users_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kkey => $k_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($k_user->id); ?>" <?php if($k_user->id == $user_id): ?> selected <?php endif; ?> ><?php echo e($k_user->first_name); ?>

                <?php echo e($k_user->last_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php endif; ?>
          </div>
        </div>

        <div class="col-md-2">
         <label for="name">.</label>
            <div>
          <button type="submit" class="btn btn-success">Actualizar
          </button>
        </div>
      </div>
      <?php echo Form::close(); ?>

    </div>
    <br>
    <div class="top-baner map-baner">
      <div id="map-canvas" data-lat="<?php echo e($user->lat); ?>" data-lng="<?php echo e($user->lng); ?>" data-zoom="16" data-style="6"></div>

      <?php if(count($locations) > 0): ?>
      <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="addresses-block">
        <a data-lat="<?php echo e($data['lat']); ?>" data-lng="<?php echo e($data['long']); ?>" data-name="<?php echo e($data['customer']); ?>"
          data-id="<?php echo e($data['loan_id']); ?>" data-amount="<?php echo e($data['amount']); ?>"></a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<script src="<?php echo e(asset('assets/themes/limitless/js/map.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>