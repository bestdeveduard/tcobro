<?php $__env->startSection('title'); ?>Credidata | Nuevo Pago
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!---<link rel="icon" href="http://jgconsultoreslegales.com/favicon.ico" type="image/x-icon" />--->
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title">Formulario de Pago
        <!---<?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?>--->
      </h2>

      <div class="heading-elements">

      </div>
    </div>
    <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/repayment/store'), 'method' => 'post', 'class' =>
    'form-horizontal')); ?>

    <div class="panel-body">

      <div class="form-group">
        <?php echo Form::label('amount',trans_choice('general.amount',1).' '." de ".'
        '.trans_choice('general.repayment',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::text('amount',null, array('class' => 'form-control touchspin', 'placeholder'=>"Ingrese el monto del
          pago sin comas",'required'=>'required')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('repayment_method_id',trans_choice('general.method',1).' '." de ".'
        '.trans_choice('general.repayment',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::select('repayment_method_id',$repayment_methods,null, array('class' => '
          form-control','required'=>'required','id'=>'loanProduct')); ?>

        </div>
      </div>
      <!-- Normal and Capital -->
      <div class="form-group">
        <label class="col-sm-3 control-label">Tipo de Pago</label>
        <div class="col-sm-5">
          <select id="repayment_type" name="repayment_type" class="form-control">
            <option value="1">Pagar cuota</option>
            <option value="2">Abono a Capital</option>
            <option value="1">Abono a Interes</option>
            <option value="1">Abono a Mora</option>
          </select>
        </div>
      </div>
      <div style="display: none;" class="form-group">
        <?php echo Form::label('receipt',trans_choice('general.receipt',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::text('receipt',"CD" . $loan->id . "0" . $loan->loan_product->id . date("Ymd") . date("his"),
          array('class' => 'form-control', 'placeholder'=>"", 'required'=>'required')); ?>

        </div>
      </div>

      <div class="form-group">
        <?php echo Form::label('collection_date',trans_choice("Fecha de pago",1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::text('collection_date',date("Y-m-d"), array('class' => 'form-control date-picker',
          'placeholder'=>"",'required'=>'required')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('notes',trans_choice("Comentarios",1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-9">
          <?php echo Form::textarea('notes',null, array('class' => 'form-control', 'rows'=>"4")); ?>

        </div>
      </div>
      <p style="display: none;" class="bg-navy disabled color-palette"><?php echo e(trans_choice('general.custom_field',2)); ?></p>
      <?php $__currentLoopData = $custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="form-group">
        <?php echo Form::label($key->id,$key->name,array('class'=>'')); ?>

        <?php if($key->field_type=="number"): ?>
        <input type="number" class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
        <?php if($key->field_type=="textfield"): ?>
        <input type="text" class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
        <?php if($key->field_type=="date"): ?>
        <input type="text" class="form-control date-picker" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
        <?php if($key->field_type=="textarea"): ?>
        <textarea class="form-control" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>></textarea>
        <?php endif; ?>
        <?php if($key->field_type=="decimal"): ?>
        <input type="text" class="form-control touchspin" name="<?php echo e($key->id); ?>" <?php if($key->required==1): ?> required <?php endif; ?>>
        <?php endif; ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <!-- /.panel-body -->
    <div class="panel-footer">
      <div class="heading-elements">
        <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>
      </div>
    </div>
    <?php echo Form::close(); ?>

  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>