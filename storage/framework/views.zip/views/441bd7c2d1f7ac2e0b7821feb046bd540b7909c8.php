<?php $__env->startSection('title'); ?>Reportes Administrativos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title">Reportes Administrativos </h2>

      <div class="heading-elements">

      </div>
    </div>

    <div class="panel-body">
      <table id="order-listing" class="table">
        <thead>
          <tr>
            <th><?php echo e(trans_choice('general.name',1)); ?></th>
            <th><?php echo e(trans_choice('general.description',1)); ?></th>
            <th><?php echo e(trans_choice('general.action',1)); ?></th>
          </tr>
        </thead>
        <tbody>

          <tr class="hidden">
            <td>
              <a href="<?php echo e(url('report/company_report/indicator_report')); ?>"><?php echo e(trans_choice('general.indicator',1)); ?>

                <?php echo e(trans_choice('general.report',1)); ?></a>
            </td>
            <td>
              <?php echo e(trans_choice('general.indicator_report_description',1)); ?>

            </td>
            <td><a href="<?php echo e(url('report/company_report/indicator_report')); ?>"><i class="icon-search4"></i> </a>
            </td>
          </tr>
          <tr class="hidden">
            <td>
              <a href="<?php echo e(url('report/company_report/loan_officer_performance')); ?>">
                <?php echo e(trans_choice('general.loan_officer',2)); ?> <?php echo e(trans_choice('general.performance',1)); ?></a>
            </td>
            <td>
              <?php echo e(trans_choice('general.loan_officer_performance_report_description',1)); ?>

            </td>
            <td><a href="<?php echo e(url('report/company_report/loan_officer_performance')); ?>"><i class="icon-search4"></i> </a>
            </td>
          </tr>

          <tr>
            <td>
              <a href="<?php echo e(url('report/company_report/products_summary')); ?>">Resumen general de Cartera</a>
            </td>
            <td>
              <?php echo e(trans_choice('general.products_summary_report_description',1)); ?>

            </td>
            <td><a href="<?php echo e(url('report/company_report/products_summary')); ?>"><i class="icon-search4"></i> </a>
            </td>
          </tr>
          <tr>
            <td>
              <a href="<?php echo e(url('report/company_report/general_report')); ?>"><?php echo e(trans_choice('general.general',2)); ?>

                <?php echo e(trans_choice('general.report',1)); ?></a>
            </td>
            <td>
              <?php echo e(trans_choice('general.general_report_description',1)); ?>

            </td>
            <td><a href="<?php echo e(url('report/company_report/general_report')); ?>"><i class="icon-search4"></i> </a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- /.panel-body -->
  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>