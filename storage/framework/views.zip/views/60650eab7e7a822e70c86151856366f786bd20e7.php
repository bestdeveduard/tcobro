<?php $__env->startSection('title'); ?>
Reporte Clientes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!---<?php echo e(trans_choice('general.borrower',2)); ?>--->
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h3 class="panel-title">Reporte de Clientes
        <!---<?php echo e(trans_choice('general.borrower',2)); ?>--->
      </h3>

      <div class="heading-elements">
        <?php if(Sentinel::hasAccess('borrowers.create')): ?>
        <a href="<?php echo e(url('borrower/create')); ?>" class="btn btn-info btn-sm"><?php echo e(trans_choice('general.add',1)); ?>

          <?php echo e(trans_choice('general.borrower',1)); ?></a>
        <?php endif; ?>
      </div>
    </div>

    <div class="row">
      <div class="col-12">
        <div class="table-responsive">
          <table id="order-listing" class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre y apellido</th>
                <th>Direccion</th>
                <th>Telefono</th>
                <th>Movil</th>
                <th>Empresa</th>
                <th>Referencia</th>
                <th>Estatus</th>
                <th>Acciones</th>
                <!---<th>Acciones</th>--->
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($key->id); ?></td>
                <td><?php echo e($key->first_name); ?> <?php echo e($key->last_name); ?></td>
                <td>
                  <?php echo e($key->address); ?>, <?php echo e($key->country->name); ?>

                </td>
                <td><?php echo e($key->phone); ?></td>
                <td><?php echo e($key->mobile); ?></td>
                <td><?php echo e($key->business_name); ?></td>
                <td><?php echo e($key->referencia_1); ?></td>
                <td>
                  <?php if($key->active==0): ?>
                  <strong>Lista negra</strong>

                  <?php elseif(count($key->loans)==0): ?>
                  <strong>Inactivo</strong>

                  <?php elseif(count($key->loans) > 0): ?>
                  <strong>Activo</strong>

                  <?php endif; ?>


                </td>

                <td class="text-center">
                  <ul class="list-group">
                    <li class="dropdown">
                      <a href="#" data-toggle="dropdown">
                        <img src="https://img.icons8.com/pastel-glyph/25/000000/plus.png" />
                      </a>

                      <ul class="dropdown-menu dropdown-menu-right" role="menu">
                        <?php if($key->active==0): ?>
                        <?php if(Sentinel::hasAccess('borrowers.approve')): ?>
                        <li><a href="<?php echo e(url('borrower/'.$key->id.'/approve')); ?>"><i class="fa fa-check"></i>Aprobar
                          </a></li>
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php if($key->active==1): ?>
                        <?php if(Sentinel::hasAccess('borrowers.approve')): ?>
                        <li><a href="<?php echo e(url('borrower/'.$key->id.'/decline')); ?>"><i class="fa fa-minus-circle"></i>
                            disminución
                          </a></li>
                        <?php endif; ?>
                        <?php endif; ?>

                        <?php if(Sentinel::hasAccess('borrowers.view')): ?>
                        <li><a href="<?php echo e(url('borrower/'.$key->id.'/show')); ?>"><i class="fa fa-search"></i>Ver perfil
                          </a></li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('borrowers.update')): ?>
                        <li><a href="<?php echo e(url('borrower/'.$key->id.'/edit')); ?>"><i class="fa fa-edit"></i>Editar</a>
                        </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('borrowers.delete')): ?>
                        <li><a href="<?php echo e(url('borrower/'.$key->id.'/delete')); ?>" class="delete"><i
                              class="fa fa-trash"></i>Eliminar
                          </a>
                        </li>
                        <?php endif; ?>
                      </ul>

                    </li>
                  </ul>
                </td>


                <!---   <td>
              <button type="button" class="btn btn-primary"><i class="far fa-eye"></i></button>
              <button type="button" class="btn btn-success"><i class="fas fa-edit"></i></button>
            <button type="button" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                        </td>--->
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- /.panel-body -->
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
<script>
$('#data-table').DataTable({
  "order": [
    [0, "desc"]
  ],
  "columnDefs": [{
    "orderable": false,
    "targets": [5]
  }],
  "language": {
    "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
    "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
    "info": "<?php echo e(trans('general.info')); ?>",
    "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
    "search": "<?php echo e(trans('general.search')); ?>",
    "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
    "paginate": {
      "first": "<?php echo e(trans('general.first')); ?>",
      "last": "<?php echo e(trans('general.last')); ?>",
      "next": "<?php echo e(trans('general.next')); ?>",
      "previous": "<?php echo e(trans('general.previous')); ?>"
    }
  },
  responsive: false
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>