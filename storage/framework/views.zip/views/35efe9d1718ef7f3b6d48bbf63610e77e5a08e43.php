<div style="width: 100%; display:block;">
  <h2>Thanks for your registered</h2>
  <p>
    <strong>Hi there!</strong><br>
      Please confirm your email address <br>
      Here is your otp code: <strong>123465</strong><br>
      It expires in 5 mins.
      <br><br>
    <strong>Sincerely</strong><br>    
  </p>
</div>