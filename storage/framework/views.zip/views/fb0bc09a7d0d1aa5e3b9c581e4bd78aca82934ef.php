
<?php $__env->startSection('title'); ?>
T-Cobro Web| Crear usuario
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <div class="col-12 grid-margin">
    <div class="card">
      <div class="card-body">

        <?php if(Session::has('flash_notification.message')): ?>
          <script>toastr.<?php echo e(Session::get('flash_notification.level')); ?>('<?php echo e(Session::get("flash_notification.message")); ?>', 'Response Status')</script>
        <?php endif; ?>
        <?php if(isset($msg)): ?>
          <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e($msg); ?>

          </div>
        <?php endif; ?>
        <?php if(isset($error)): ?>
          <div class="alert alert-error">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e($error); ?>

          </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?> 

        <h4>Nuevo usuario</h4>
        <br>
        <?php echo Form::open(array('url' => url('super_admin/saveadmin'), 'method' => 'post', 'name' => 'form','class'=>'form-sample')); ?>

          <p class="card-description">
            <h5 style="color:#46b979;">Informacion Personal</h5>
          </p>
          <br>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Nombre *</strong></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="first_name" id="first_name" required="true" placeholder="Jose"/>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Apellido *</strong></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Perez" required="true"/>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Email *</strong></label>
                <div class="col-sm-8">
                    <input type="email" class="form-control" name="email" id="email" placeholder="example@hotmail.com" required="true"/>
                </div>
              </div>
            </div>
            

            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Pais *</strong></label>
                <div class="col-sm-8">
                  <select class="form-control" name="country_id" id="country_id" required="true">
                    <option disabled selected>Seleccione</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->id); ?>" <?php if($country->id == 61): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                  </select>
                </div>
              </div>
            </div>                      
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Telefono *</strong></label>
                <div class="col-sm-8">
                    <input type="number" class="form-control" name="phone" id="phone" placeholder="+(999) 999-9999" required="true"/>
                    
                </div>
              </div>
            </div>
            

            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Planes *</strong></label>
                <div class="col-sm-8">
                  <select class="form-control" class="form-control" name="plan_id" id="plan_id">
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($plan->id); ?>"><?php echo e($plan->name); ?> - $<?php echo e($plan->amount); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                  </select>
                </div>
              </div>
            </div>                      
          </div>              

          <p class="card-description">
            <h5 style="color:#46b979;">Informacion de acceso</h5>
          </p>
          <br>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Usuario *</strong></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="user_name" id="user_name" placeholder="" required="true"/>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group row">
                <label class="col-sm-3 col-form-label"><strong>Password *</strong></label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" name="password" id="password" placeholder="******" required="true"/>
                </div>
              </div>
            </div>
          </div>

          <button style="width:115px;" type="submit" class="btn btn-primary mr-2">Guardar</button>
          <a style="width:115px;" class="btn btn-light" href="<?php echo e(url('super_admin/admin')); ?>">Cancelar</a>

        <?php echo Form::close(); ?>


      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>