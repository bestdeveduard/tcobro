
<?php $__env->startSection('title'); ?>
    T-Cobro Web
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper" style="padding-top: 5px;">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">

              <?php if(Session::has('flash_notification.message')): ?>
                  <script>toastr.<?php echo e(Session::get('flash_notification.level')); ?>('<?php echo e(Session::get("flash_notification.message")); ?>', 'Response Status')</script>
              <?php endif; ?>
              <?php if(isset($msg)): ?>
                  <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <?php echo e($msg); ?>

                  </div>
              <?php endif; ?>
              <?php if(isset($error)): ?>
                  <div class="alert alert-error">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <?php echo e($error); ?>

                  </div>
              <?php endif; ?>
              <?php if(count($errors) > 0): ?>
                  <div class="alert alert-danger">
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
              <?php endif; ?>

              <div class="brand-logo">
                <center>
                    <img src="<?php echo e(asset('logo.png')); ?>" alt="logo">
                </center>
              </div>

              <center>
                <h4>Hemos enviado un codigo de confirmacion a su correo electronico</h4>
              </center>
              
              <?php echo Form::open(array('url' => url('verifyotp'), 'method' => 'post', 'name' => 'form','class'=>'pt-3')); ?>


                <br>
                <br>
                <h6 class="font-weight-light">Ingresar codigo</h6>
                <div class="form-group">
                  <?php echo Form::number('otp_code', null, array('class' => 'form-control', 'placeholder'=>'Codigo OTP','required'=>'required', 'id'=>'otp_code')); ?>

                  <input type="hidden" name="user_id" id="user_id" value="<?php echo e(\Session::get('user_id')); ?>">
                </div>
                <br>

                <div class="mt-3">
                  <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit">Validar</button>
                </div>

                <div class="mt-3">
                  <a class="btn btn-block btn-dark btn-lg font-weight-medium auth-form-btn" href="<?php echo e(asset('admin_register')); ?>">Reenviar</a>
                </div>              

              <?php echo Form::close(); ?>


            </div>
          </div>
        </div>
      </div>      
    </div>    
  </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>