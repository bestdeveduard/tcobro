
<?php $__env->startSection('title'); ?>
T-Cobro Web | Prestamos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">

    <div class="panel-heading">
      <h2 class="panel-title">

        <?php if(isset($_REQUEST['status'])): ?>
        <?php if($_REQUEST['status']=='pending'): ?>
        Pendiente de aprobacion
        <?php endif; ?>
        <?php if($_REQUEST['status']=='approved'): ?>
        Pendiente de desembolso
        <?php endif; ?>
        <?php if($_REQUEST['status']=='disbursed'): ?>
        <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.disbursed',1)); ?>

        <?php endif; ?>
        <?php if($_REQUEST['status']=='declined'): ?>
        <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.declined',1)); ?>

        <?php endif; ?>
        <?php if($_REQUEST['status']=='withdrawn'): ?>
        <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.withdrawn',1)); ?>

        <?php endif; ?>
        <?php if($_REQUEST['status']=='written_off'): ?>
        <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.written_off',1)); ?>

        <?php endif; ?>
        <?php if($_REQUEST['status']=='closed'): ?>
        <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.closed',1)); ?>

        <?php endif; ?>
        <?php if($_REQUEST['status']=='rescheduled'): ?>
        <?php echo e(trans_choice('general.loan',2)); ?> <?php echo e(trans_choice('general.rescheduled',1)); ?>

        <?php endif; ?>
        <?php else: ?>
        Prestamos
        <?php endif; ?>
      </h2>
      <div class="heading-elements">
        <?php if(Sentinel::hasAccess('loans.create')): ?>
        <a href="<?php echo e(url('loan/create')); ?>" class="btn btn-info btn-sm">Crear Prestamo</a>
        <?php endif; ?>
      </div>
    </div>
    <div class="panel-body table-responsive">
      <table id="order-listing" class="table">
        <thead>
          <tr>
            <th>#</th>
            <th>Nombres & apellidos</th>
            <th>Capital prestado</th>
            <th>Desembolsado</th>
            <th>Ruta</th>
            <th>Cuotas</th>
            <th>Ganancias</th>
            <th>Balance</th>            
            <th>Estatus</th>
            <!---<th>Acciones</th>--->
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key->id); ?></td>
            <td>
              <?php if(!empty($key->borrower)): ?>
              <a href="<?php echo e(url('loan/'.$key->id.'/show')); ?>"><?php echo e($key->borrower->first_name); ?>

                <?php echo e($key->borrower->last_name); ?></a>
              <?php else: ?>
              <span class="label label-danger"><?php echo e(trans_choice('general.broken',1)); ?> <i
                  class="fa fa-exclamation-triangle"></i> </span>
              <?php endif; ?>
            </td>
            <td>
              <?php if(\App\Models\Setting::where('setting_key', 'currency_position')->first()->setting_value=='left'): ?>
              $<?php echo e(number_format($key->principal,2)); ?>

              <?php else: ?>
              $<?php echo e(number_format($key->principal,2)); ?>

              <?php endif; ?>
            </td>
            <td><?php echo e($key->release_date); ?></td>
            <td>
              <?php if(!empty($key->loan_product)): ?>
              <?php echo e($key->loan_product->name); ?>

              <?php else: ?>
              <label style="width: 100px;" class="badge badge-danger">No encontrado</label>
              <?php endif; ?>
            </td>
            <td>
            <?php 
              $paid_count = 0;
              $paid_amount = 0;
              $unpaid_count = 0;
              $unpaid_amount = 0;

              $paid_rate = 0;
              $unpaid_rate = 0;

              $totalPrincipal = \App\Models\LoanSchedule::where('loan_id', $key->id)->sum('principal');
              $payPrincipal = \App\Models\LoanTransaction::where('loan_id', $key->id)->where('transaction_type', 'repayment')->where('reversed', 0)->where('payment_type', 'principal')->sum('credit');
              $balancePrincipal = $totalPrincipal - $payPrincipal;

              $loan_schedules = \App\Models\LoanSchedule::where('loan_id', $key->id)->get();
              $payments = \App\Models\LoanTransaction::where('loan_id', $key->id)->where('transaction_type', 'repayment')->where('reversed', 0)->where('payment_type', 'regular')->sum('credit');

              foreach ($loan_schedules as $schedule) {
                  $schedule_count = count($loan_schedules);
                  $principal = $balancePrincipal / $schedule_count;            
                  $loanRate = $key->interest_rate;

                  if ($key->repayment_cycle=='daily') {
                      $interest = (($balancePrincipal * $loanRate) / 100.00) / 30;
                  } elseif ($key->repayment_cycle=='weekly') {
                      $interest = (($balancePrincipal * $loanRate) / 100.00) / 4;
                  } elseif ($key->repayment_cycle=='bi_monthly') {
                      $interest = (($balancePrincipal * $loanRate) / 100.00) / 2;
                  } elseif ($key->repayment_cycle=='monthly') {
                      $interest = ($balancePrincipal * $loanRate) / 100.00;        
                  } else {
                      $interest = 0;
                  }            
                                      
                  $due = $principal + $interest + $schedule->fees + $schedule->penalty - $schedule->interest_waived;
                  $paid = 0;
                                                  
                  if ($payments > 0) {
                      if ($payments > $due) {
                          $paid = $due;
                          $payments = $payments - $due;                    
                      } else {
                          $paid = $payments;
                          $payments = 0;
                      }
                  } else {
                  }
                  $outstanding = $due - $paid;
                              
                  if ($outstanding == 0) {
                      $paid_amount = $paid_amount + $paid;
                      $paid_count = $paid_count + 1;                
                  }
                  if ($outstanding != 0) {
                      $unpaid_amount = $unpaid_amount + $outstanding;
                      $unpaid_count = $unpaid_count + 1;
                  }
                  $paid_rate = $paid_rate + $paid / $due;
                  $unpaid_rate = $unpaid_rate + $outstanding / $due;
              }
               ?>
              <?php echo e(number_format($paid_rate, 2, '.', "")); ?> de <?php echo e($paid_count + $unpaid_count); ?>

            </td>
            <td>
            <?php 
              $total_principal = 0;
              $total_fees = 0;
              $total_interest = 0;
              $total_penalty = 0;
              $transaction_type = '';
              $transaction_date = '';
              foreach (\App\Models\LoanTransaction::where('transaction_type', 'repayment')->where('reversed', 0)->where('loan_id', $key->id)->where('branch_id', Sentinel::getUser()->business_id)->get() as $trans) {                  

                  $interest = \App\Models\JournalEntry::where('loan_transaction_id', $trans->id)->where('reversed',0)->where('name', "Interest Repayment")->sum('credit');

                  $fees = \App\Models\JournalEntry::where('loan_transaction_id', $trans->id)->where('reversed',0)->where('name', "Fees Repayment")->sum('credit');

                  $penalty = \App\Models\JournalEntry::where('loan_transaction_id', $trans->id)->where('reversed',0)->where('name', "Penalty Repayment")->sum('credit');

                  $total_principal = $total_principal + $principal;
                  $total_interest = $total_interest + $interest;
                  $total_fees = $total_fees + $fees;
                  $total_penalty = $total_penalty + $penalty;

                  $transaction_type = $key->transaction_type;            
              }
             ?>
            $<?php echo e(number_format($total_interest + $total_fees + $total_penalty, 2, '.', "")); ?>

            </td>
            <td>
            <?php if($key->status=='closed'): ?>
            $0.00
            <?php else: ?>
              $<?php echo e(number_format(\App\Helpers\GeneralHelper::loan_total_balance($key->id),2)); ?>

            <?php endif; ?>  
             </td>            
            <td>
              <?php if($key->maturity_date<date("Y-m-d") && \App\Helpers\GeneralHelper::loan_total_balance($key->id)>0): ?>
              <span class="label label-danger">Vencido</span>
              <?php else: ?>
                <?php if($key->status=='pending'): ?>
                <span class="label label-warning">Pendiente de aprobacion</span>
                <?php endif; ?>
                <?php if($key->status=='approved'): ?>
                <span class="label label-warning">Pendiente de desembolso</span>
                <?php endif; ?>
                <?php if($key->status=='disbursed'): ?>
                <label style="width: 100px;" class="badge badge-success">Activo</label>
                <?php endif; ?>
                <?php if($key->status=='declined'): ?>
                <span class="label label-danger">Declinado</span>
                <?php endif; ?>
                <?php if($key->status=='withdrawn'): ?>
                <span class="label label-danger"><?php echo e(trans_choice('general.withdrawn',1)); ?></span>
                <?php endif; ?>
                <?php if($key->status=='written_off'): ?>
                <span class="label label-danger">Llevado a perdida</span>
                <?php endif; ?>
                <?php if($key->status=='closed'): ?>
                <label style="width: 100px;" class="badge badge-secondary">Cancelado</label>
                <?php endif; ?>
                <?php if($key->status=='pending_reschedule'): ?>
                <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?>

                  <?php echo e(trans_choice('general.reschedule',1)); ?></span>
                <?php endif; ?>
                <?php if($key->status=='rescheduled'): ?>
                <span class="label label-info"><?php echo e(trans_choice('general.rescheduled',1)); ?></span>
                <?php endif; ?>
              <?php endif; ?>
            </td>
            <!---<td>
              <ul class="icons-list">
                <li class="dropdown">
                  <a href="#" data-toggle="dropdown">
                    <img src="https://img.icons8.com/pastel-glyph/25/000000/plus.png" />
                  </a>
                  <ul class="dropdown-menu dropdown-menu-right" role="menu">
                    <?php if(Sentinel::hasAccess('loans.view')): ?>
                    <li><a href="<?php echo e(url('loan/'.$key->id.'/show')); ?>"><i class="fa fa-search"></i>Abrir
                      </a>
                    </li>
                    <?php endif; ?>
                    <?php if(Sentinel::hasAccess('loans.create')): ?>
                    <li><a href="<?php echo e(url('loan/'.$key->id.'/edit')); ?>"><i class="fa fa-edit"></i>Editar</a>
                    </li>
                    <?php endif; ?>
                    <?php if(Sentinel::hasAccess('loans.delete')): ?>
                    <li><a href="<?php echo e(url('loan/'.$key->id.'/delete')); ?>" class="delete"><i
                          class="fa fa-trash"></i>Eliminar</a>
                    </li>
                    <?php endif; ?>
                  </ul>
                </li>
              </ul>
            </td>--->
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.panel-body -->
  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<script>
$('#data-table').DataTable({
  "order": [
    [4, "desc"]
  ],
  "columnDefs": [{
    "orderable": false,
    "targets": [7]
  }],
  "language": {
    "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
    "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
    "info": "<?php echo e(trans('general.info')); ?>",
    "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
    "search": "<?php echo e(trans('general.search')); ?>",
    "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
    "paginate": {
      "first": "<?php echo e(trans('general.first')); ?>",
      "last": "<?php echo e(trans('general.last')); ?>",
      "next": "<?php echo e(trans('general.next')); ?>",
      "previous": "<?php echo e(trans('general.previous')); ?>"
    }
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>