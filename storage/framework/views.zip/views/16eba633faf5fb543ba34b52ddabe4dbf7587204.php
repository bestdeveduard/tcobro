
<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.balance',1)); ?> <?php echo e(trans_choice('general.sheet',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h6 class="panel-title">
        <?php echo e(trans_choice('general.balance',1)); ?> <?php echo e(trans_choice('general.sheet',1)); ?>

        <?php if(!empty($start_date)): ?>
        as at: <b><?php echo e($start_date); ?> </b>
        <?php endif; ?>
      </h6>

      <div class="heading-elements">

      </div>
    </div>
    <div class="panel-body hidden-print">
      <h4 class=""><?php echo e(trans_choice('general.date',1)); ?> <?php echo e(trans_choice('general.range',1)); ?></h4>
      <?php echo Form::open(array('url' => Request::url(), 'method' => 'post','class'=>'form-horizontal', 'name' => 'form')); ?>

      <div class="row">
        <div class="col-md-2">
          <?php echo Form::date('start_date',$start_date, array('class' => 'form-control date-picker', 'placeholder'=>"End
          Date",'required'=>'required')); ?>

        </div>
      </div>
      <br>
      
      <div class="panel-body">
        <div class="row">
          <div class="col-md-12">

            <button type="submit" class="btn btn-success"><?php echo e(trans_choice('general.search',1)); ?>!
            </button>

            <a href="<?php echo e(Request::url()); ?>" class="btn btn-danger"><?php echo e(trans_choice('general.reset',1)); ?>!</a>

            <div class="btn-group">
              <button type="button" class="btn dropdown-toggle legitRipple"
                data-toggle="dropdown"><?php echo e(trans_choice('general.download',1)); ?> <?php echo e(trans_choice('general.report',1)); ?>

                </button>
              <ul class="dropdown-menu dropdown-menu-right">
                <li>
                  <a href="<?php echo e(url('report/financial_report/balance_sheet/pdf?start_date='.$start_date.'&end_date='.$end_date)); ?>"
                    target="_blank" style="font-size: 13px; margin-top: 5px; padding: 0 10px;"><i class="icon-file-pdf"></i> <span style="position: relative; top: -6px;"><?php echo e(trans_choice('general.download',1)); ?>

                    <?php echo e(trans_choice('general.to',1)); ?> <?php echo e(trans_choice('general.pdf',1)); ?></span>
                  </a>
                </li>
                <li>
                  <a href="<?php echo e(url('report/financial_report/balance_sheet/excel?start_date='.$start_date.'&end_date='.$end_date)); ?>"
                    target="_blank" style="font-size: 13px; margin-top: 5px; padding: 0 10px;"><i class="icon-file-excel"></i> <span style="position: relative; top: -6px;"><?php echo e(trans_choice('general.download',1)); ?>

                    <?php echo e(trans_choice('general.to',1)); ?> <?php echo e(trans_choice('general.excel',1)); ?></span>
                  </a>
                </li>
                <li>
                  <a href="<?php echo e(url('report/financial_report/balance_sheet/csv?start_date='.$start_date.'&end_date='.$end_date)); ?>"
                    target="_blank" style="font-size: 13px; margin-top: 5px; padding: 0 10px;"><i class="icon-download"></i> <span style="position: relative; top: -6px;"><?php echo e(trans_choice('general.download',1)); ?>

                    <?php echo e(trans_choice('general.to',1)); ?> <?php echo e(trans_choice('general.csv',1)); ?></span>
                  </a>
                </li>
              </ul>
            </div>

          </div>
        </div>
      </div>
      <?php echo Form::close(); ?>


    </div>
    <!-- /.panel-body -->

  </div>
  <!-- /.box -->
  <?php if(!empty($start_date)): ?>
  <div class="card-body">
    <div class="panel-body table-responsive no-padding">

      <table id="order-listing" class="table">
        <thead>
          <tr>
            <th><?php echo e(trans_choice('general.gl_code',1)); ?></th>
            <th><?php echo e(trans_choice('general.account',1)); ?></th>
            <th><?php echo e(trans_choice('general.balance',1)); ?></th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td colspan="3" style="text-align: left"><b><?php echo e(trans_choice('general.asset',2)); ?></b></td>
          </tr>
          <?php
                    $total_liabilities = 0;
                    $total_assets = 0;
                    $total_equity = 0;
                    $retained_earnings = 0;
                    ?>
          <?php $__currentLoopData = \App\Models\ChartOfAccount::where('account_type','asset')->orderBy('gl_code','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
                        $balance = 0;
                        $cr = \App\Models\JournalEntry::where('account_id', $key->id)->where('date', '<=',
                            $start_date)->where('branch_id',
                            session('branch_id'))->sum('credit');
                        $dr = \App\Models\JournalEntry::where('account_id', $key->id)->where('date', '<=',
                            $start_date)->where('branch_id',
                            session('branch_id'))->sum('debit');
                        $balance = $dr - $cr;
                        $total_assets = $total_assets + $balance;
                        ?>
          <tr>
            <td><?php echo e($key->gl_code); ?></td>
            <td>
              <?php echo e($key->name); ?>

            </td>
            <td><?php echo e(number_format($balance,2)); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="2" style="text-align: right">
              <b><?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.asset',2)); ?></b>
            </td>
            <td><b><?php echo e(number_format($total_assets,2)); ?></b></td>
          </tr>
          <tr>
            <td colspan="3" style="text-align: left"><b><?php echo e(trans_choice('general.liability',2)); ?></b></td>
          </tr>
          <?php $__currentLoopData = \App\Models\ChartOfAccount::where('account_type','liability')->orderBy('gl_code','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
                        $balance = 0;
                        $cr = \App\Models\JournalEntry::where('account_id', $key->id)->where('date', '<=',
                            $start_date)->where('branch_id',
                            session('branch_id'))->sum('credit');
                        $dr = \App\Models\JournalEntry::where('account_id', $key->id)->where('date', '<=',
                            $start_date)->where('branch_id',
                            session('branch_id'))->sum('debit');
                        $balance = $cr - $dr;
                        $total_liabilities = $total_liabilities + $balance;
                        ?>
          <tr>
            <td><?php echo e($key->gl_code); ?></td>
            <td>
              <?php echo e($key->name); ?>

            </td>
            <td><?php echo e(number_format($balance,2)); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="2" style="text-align: right">
              <b><?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.liability',2)); ?></b>
            </td>
            <td><b><?php echo e(number_format($total_liabilities,2)); ?></b></td>
          </tr>
          <tr>
            <td colspan="3" style="text-align: left"><b><?php echo e(trans_choice('general.equity',2)); ?></b></td>
          </tr>
          <?php $__currentLoopData = \App\Models\ChartOfAccount::where('account_type','equity')->orderBy('gl_code','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
                        $balance = 0;
                        $cr = \App\Models\JournalEntry::where('account_id', $key->id)->where('date', '<=',
                            $start_date)->where('branch_id',
                            session('branch_id'))->sum('credit');
                        $dr = \App\Models\JournalEntry::where('account_id', $key->id)->where('date', '<=',
                            $start_date)->where('branch_id',
                            session('branch_id'))->sum('debit');
                        $balance = $cr - $dr;
                        $total_equity = $total_equity + $balance;
                        ?>
          <tr>
            <td><?php echo e($key->gl_code); ?></td>
            <td>
              <?php echo e($key->name); ?>

            </td>
            <td><?php echo e(number_format($balance,2)); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="2" style="text-align: right">
              <b><?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.equity',2)); ?></b>
            </td>
            <td><b><?php echo e(number_format($total_equity,2)); ?></b></td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="2" style="text-align: right">
              <b><?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.liability',2)); ?>

                <?php echo e(trans_choice('general.and',1)); ?> <?php echo e(trans_choice('general.equity',2)); ?></b>
            </td>
            <td><b><?php echo e(number_format($total_liabilities+$total_equity,2)); ?></b></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>