<div style="width: 100%; display:block;">
  <h2>Gracias por utilizar TCobros</h2>
  <p>
    <strong>Hola. <?php echo e($first_name); ?> <?php echo e($last_name); ?>!</strong><br>
    Para confirmar tu correo electronico <br>
    Introduzca este codigo OTP para continuar el proceso de registro: <strong><?php echo e($otp_code); ?></strong><br>
    Este codigo tiene una duracion de 5 minutos.
    <br><br>
  </p>
</div>