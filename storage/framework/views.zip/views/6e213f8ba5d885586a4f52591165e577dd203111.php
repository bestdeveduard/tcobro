
<?php $__env->startSection('title'); ?>
    Detalles del prestamo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
    //determine interest rate
    $interest_rate = 0;
    if ($request->repayment_cycle == 'annually') {
        //return the interest per year
        if ($request->interest_period == 'year') {
            $interest_rate = $request->interest_rate;
        }
        if ($request->interest_period == 'month') {
            $interest_rate = $request->interest_rate * 12;
        }
        if ($request->interest_period == 'week') {
            $interest_rate = $request->interest_rate * 52;
        }
        if ($request->interest_period == 'day') {
            $interest_rate = $request->interest_rate * 360;
        }
    }
//    if ($request->repayment_cycle == 'semi_annually') {
//        //return the interest per semi annually
//        if ($request->interest_period == 'year') {
//            $interest_rate = $request->interest_rate / 2;
//        }
//        if ($request->interest_period == 'month') {
//            $interest_rate = $request->interest_rate * 6;
//        }
//        if ($request->interest_period == 'week') {
//            $interest_rate = $request->interest_rate * 26;
//        }
//        if ($request->interest_period == 'day') {
//            $interest_rate = $request->interest_rate * 182.5;
//        }
//    }
//    if ($request->repayment_cycle == 'quarterly') {
//        //return the interest per quaterly
//
//        if ($request->interest_period == 'year') {
//            $interest_rate = $request->interest_rate / 4;
//        }
//        if ($request->interest_period == 'month') {
//            $interest_rate = $request->interest_rate * 3;
//        }
//        if ($request->interest_period == 'week') {
//            $interest_rate = $request->interest_rate * 13;
//        }
//        if ($request->interest_period == 'day') {
//            $interest_rate = $request->interest_rate * 91.25;
//        }
//    }
    if ($request->repayment_cycle == 'bi_monthly') {
        //return the interest per bi-monthly
        if ($request->interest_period == 'year') {
            $interest_rate = $request->interest_rate / 6;
        }
        if ($request->interest_period == 'month') {
            $interest_rate = $request->interest_rate / 2;
        }
        if ($request->interest_period == 'week') {
            $interest_rate = $request->interest_rate / 8;
        }
        if ($request->interest_period == 'day') {
            $interest_rate = $request->interest_rate / 58;
        }

    }

    if ($request->repayment_cycle == 'monthly') {
        //return the interest per monthly

        if ($request->interest_period == 'year') {
            $interest_rate = $request->interest_rate / 12;
        }
        if ($request->interest_period == 'month') {
            $interest_rate = $request->interest_rate * 1;
        }
        if ($request->interest_period == 'week') {
            $interest_rate = $request->interest_rate * 4;
        }
        if ($request->interest_period == 'day') {
            $interest_rate = $request->interest_rate * 30;
        }
    }
    if ($request->repayment_cycle == 'weekly') {
        //return the interest per weekly

        if ($request->interest_period == 'year') {
            $interest_rate = $request->interest_rate / 52;
        }
        if ($request->interest_period == 'month') {
            $interest_rate = $request->interest_rate / 4;
        }
        if ($request->interest_period == 'week') {
            $interest_rate = $request->interest_rate;
        }
        if ($request->interest_period == 'day') {
            $interest_rate = $request->interest_rate * 7;
        }
    }
    if ($request->repayment_cycle == 'daily') {
        //return the interest per day

        if ($request->interest_period == 'year') {
            $interest_rate = $request->interest_rate / 360;
        }
        if ($request->interest_period == 'month') {
            $interest_rate = $request->interest_rate / 30;
        }
        if ($request->interest_period == 'week') {
            $interest_rate = $request->interest_rate / 7;
        }
        if ($request->interest_period == 'day') {
            $interest_rate = $request->interest_rate * 1;
        }
    }
    $interest_rate = $interest_rate / 100;
    $period = 0;
    if ($request->repayment_cycle == 'annually') {
        if ($request->loan_duration_type == 'year') {
            $period = ceil($request->loan_duration);
        }
        if ($request->loan_duration_type == 'month') {
            $period = ceil($request->loan_duration * 12);
        }
        if ($request->loan_duration_type == 'week') {
            $period = ceil($request->loan_duration * 52);
        }
        if ($request->loan_duration_type == 'day') {
            $period = ceil($request->loan_duration * 360);
        }
    }
    if ($request->repayment_cycle == 'semi_annually') {
        if ($request->loan_duration_type == 'year') {
            $period = ceil($request->loan_duration * 2);
        }
        if ($request->loan_duration_type == 'month') {
            $period = ceil($request->loan_duration * 6);
        }
        if ($request->loan_duration_type == 'week') {
            $period = ceil($request->loan_duration * 26);
        }
        if ($request->loan_duration_type == 'day') {
            $period = ceil($request->loan_duration * 182.5);
        }
    }
    if ($request->repayment_cycle == 'quarterly') {
        if ($request->loan_duration_type == 'year') {
            $period = ceil($request->loan_duration);
        }
        if ($request->loan_duration_type == 'month') {
            $period = ceil($request->loan_duration * 12);
        }
        if ($request->loan_duration_type == 'week') {
            $period = ceil($request->loan_duration * 52);
        }
        if ($request->loan_duration_type == 'day') {
            $period = ceil($request->loan_duration * 360);
        }
    }
    if ($request->repayment_cycle == 'bi_monthly') {
        if ($request->loan_duration_type == 'year') {
            $period = ceil($request->loan_duration * 24);
        }
        if ($request->loan_duration_type == 'month') {
            $period = ceil($request->loan_duration * 2);
        }
        if ($request->loan_duration_type == 'week') {
            $period = ceil($request->loan_duration * 8);
        }
        if ($request->loan_duration_type == 'day') {
            $period = ceil($request->loan_duration * 60);
        }
    }

    if ($request->repayment_cycle == 'monthly') {
        if ($request->loan_duration_type == 'year') {
            $period = ceil($request->loan_duration * 12);
        }
        if ($request->loan_duration_type == 'month') {
            $period = ceil($request->loan_duration * 1);
        }
        if ($request->loan_duration_type == 'week') {
            $period = ceil($request->loan_duration * 4);
        }
        if ($request->loan_duration_type == 'day') {
            $period = ceil($request->loan_duration * 30);
        }
    }
    if ($request->repayment_cycle == 'weekly') {
        if ($request->loan_duration_type == 'year') {
            $period = ceil($request->loan_duration * 52);
        }
        if ($request->loan_duration_type == 'month') {
            $period = ceil($request->loan_duration * 4);
        }
        if ($request->loan_duration_type == 'week') {
            $period = ceil($request->loan_duration * 1);
        }
        if ($request->loan_duration_type == 'day') {
            $period = ceil($request->loan_duration * 7);
        }
    }
    if ($request->repayment_cycle == 'daily') {
        if ($request->loan_duration_type == 'year') {
            $period = ceil($request->loan_duration * 360);
        }
        if ($request->loan_duration_type == 'month') {
            $period = ceil($request->loan_duration * 30);
        }
        if ($request->loan_duration_type == 'week') {
            $period = ceil($request->loan_duration * 7);
        }
        if ($request->loan_duration_type == 'day') {
            $period = ceil($request->loan_duration * 1);
        }
    }
    
    // echo 'repayment_cycle = '.$request->repayment_cycle;
    // echo ', loan_duration_type = '.$request->loan_duration_type;
    // echo ', interest_period = '.$request->interest_period;
    ?>
    <div class="panel panel-white">
        <div class="panel-body table-responsive no-padding">
            <table id="" class="table table-bordered table-condensed table-hover">
                <thead>
                <tr style="background-color:#2b2c49;color:#FFFFFF;">
                    <th><?php echo e(trans_choice('general.released',1)); ?></th>
                    <th>Ultimo pago</th>
                    <th>Frecuencia</th>
                    <th>Capital</th>
                    <th>Tasa %</th>
                    <th>Total Interes</th>
                    <!---<th>Ajustes</th>--->
                    <th>Total</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo e($request->release_date); ?></td>
                    <td><?php echo e(date_format(date_add(date_create($request->first_payment_date),
            date_interval_create_from_date_string($period .' '.$request->interest_period. 's')),'Y-m-d')); ?></td>
                    <td id="repayment">
                        <?php if($request->repayment_cycle=='daily'): ?>
                            Diaria
                        <?php endif; ?>
                        <?php if($request->repayment_cycle=='weekly'): ?>
                            Semanal
                        <?php endif; ?>
                        <?php if($request->repayment_cycle=='monthly'): ?>
                            Mensual
                        <?php endif; ?>
                        <?php if($request->repayment_cycle=='bi_monthly'): ?>
                            Quincenal
                        <?php endif; ?>
                        <?php if($request->repayment_cycle=='quarterly'): ?>
                            <?php echo e(trans_choice('general.quarterly',1)); ?>

                        <?php endif; ?>
                        <?php if($request->repayment_cycle=='semi_annual'): ?>
                            <?php echo e(trans_choice('general.semi_annually',1)); ?>

                        <?php endif; ?>
                        <?php if($request->repayment_cycle=='annually'): ?>
                            <?php echo e(trans_choice('general.annual',1)); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e(number_format($request->principal,2)); ?></td>
                    <?php
                    $capital = $request->principal;
                    $tasa = $request->interest_rate;
                    $tiempo = $request->loan_duration;
                    $due_interest = (($capital * $tasa) / 100) * $tiempo;
                    
                    
                    ?>                    
                    <td>  <?php echo e(number_format($request->interest_rate,2)); ?>% / <?php echo e($request->interest_period); ?></td>
                    <td><?php echo e(number_format($due_interest,2)); ?></td>
                    <!---<td id="fees">0</td>-->
                    <!--- Total reporte principio--->
                    <?php
                    $capital = $request->principal;
                    $tasa = $request->interest_rate;
                    $tiempo = $request->loan_duration;
                    $due_new = ((($capital * $tasa) / 100) * $tiempo) + $capital;
                    
                    
                    ?>
                    <td><?php echo e(number_format($due_new,2)); ?></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    
    <script type="text/javascript">
        function updatesum() {
            var principalTotal = 0;
            var interestTotal = 0;
            var feesTotal = 0;
            var penaltyTotal = 0;
            var inputTotalDueAmountTotal = 0;

            for (var i = 0; i < '<?php echo e($period); ?>'; i++) {
                var principal = document.getElementById("principal" + i).value;
                var interest = document.getElementById("interest" + i).value;
                var fees = document.getElementById("fees" + i).value;
                var penalty = document.getElementById("penalty" + i).value;

                if (principal == "")
                    principal = 0;
                if (interest == "")
                    interest = 0;
                if (fees == "")
                    fees = 0;
                if (penalty == "")
                    penalty = 0;

                var totaldue = parseFloat(principal) + parseFloat(interest) + parseFloat(fees) + parseFloat(penalty);
                document.getElementById("due" + i).value = Math.floor(totaldue * 100) / 100;

                principalTotal = parseFloat(principalTotal) + parseFloat(principal) * 100;
                interestTotal = parseFloat(interestTotal) + parseFloat(interest) * 100;
                feesTotal = parseFloat(feesTotal) + parseFloat(fees) * 100;
                penaltyTotal = parseFloat(penaltyTotal) + parseFloat(penalty) * 100;

                inputTotalDueAmountTotal = parseFloat(inputTotalDueAmountTotal) + parseFloat(totaldue) * 100;
            }
            document.getElementById("principalTotal").value = Math.floor(principalTotal * 100) / 10000;
            document.getElementById("interestTotal").value = Math.floor(interestTotal * 100) / 10000;
            document.getElementById("feesTotal").value = Math.floor(feesTotal * 100) / 10000;
            document.getElementById("penaltyTotal").value = Math.floor(penaltyTotal * 100) / 10000;
            document.getElementById("inputTotalDueAmountTotal").value = Math.floor(inputTotalDueAmountTotal * 100) / 10000;

            var total_principal_amount = 0;
            var pending_balance = 0;
            var principalTotal = document.getElementById("principalTotal").value;
            for (var i = 0; i < '<?php echo e($period); ?>'; i++) {
                var principal = document.getElementById("principal" + i).value;
                total_principal_amount = (parseFloat(total_principal_amount) + parseFloat(principal));
                pending_balance = parseFloat(principalTotal) - parseFloat(total_principal_amount);
                document.getElementById("principal_balance" + i).value = Math.ceil(pending_balance * 100) / 100;
            }

        }
    </script>
    
    <div class="panel panel-white">
        <div class="panel-heading" style="background-color:#2b2c49;color:#FFFFFF;">
            <h3 class="panel-title">Calendario de pagos</h3>
            <div class="heading-elements">
            </div>
        </div>
        <?php echo Form::open(array('url' => url('loan/loan_calculator/store'), 'method' => 'post','target'=>'_blank', 'class' => 'form-horizontal')); ?>

        <input type="hidden" name="release_date" value="<?php echo e($request->release_date); ?>">
        <input type="hidden" name="maturity_date" value="<?php echo e(date_format(date_add(date_create($request->first_payment_date),
            date_interval_create_from_date_string($period .' '.$request->interest_period. 's')),'Y-m-d')); ?>">
        <input type="hidden" name="repayment_cycle" id="repayment_cycle" value="<?php echo e($request->repayment_cycle); ?>">
        <input type="hidden" name="interest_rate" id="interest_rate" value="<?php echo e($request->interest_rate); ?>">
        <input type="hidden" name="release_date" value="<?php echo e($request->release_date); ?>">
        <input type="hidden" name="interest_period" value="<?php echo e($request->interest_period); ?>">
        <input type="hidden" name="first_payment_date" value="<?php echo e($request->first_payment_date); ?>">
        <input type="hidden" name="principal_amount" value="<?php echo e($request->principal); ?>">
        <input type="hidden" name="total_interest" id="total_interest_field" value="">
        <input type="hidden" name="total_due" id="total_due_field" value="">

        <div class="panel-body table-responsive no-padding">
            <div class="row margin">
                <!---<button type="submit" name="pdf" value="submit"
                        class="btn btn-info pull-right margin"><?php echo e(trans_choice('general.download',1)); ?> <?php echo e(trans_choice('general.pdf',1)); ?>

                </button>--->
                .
                <button type="submit" name="print" value="submit"
                        class="btn btn-success pull-right margin"> Imprimir calendario
                </button>
            
            <a type="button" class="btn btn-info pull-right margin"
               href="<?php echo e(url('loan/loan_calculator/create')); ?>">
                Regresar al formulario
            </a>
            
            </div>
            <table class="table table-sm">
                <thead>
                <tr style="background-color:#2b2c49;color:#FFFFFF;">
                    <th>#</th>
                    <th style="height=100%;">Fecha</th>
                    <th style="height=100%;">Capital</th>
                    
                    <th style="height=100%;">Interes</th>
                    
                    <th style="height=100%;">Ajustes</th>
                   
                    <th style="height=100%;">Penalidad</th>
                   
                    <th>Cuota a Pagar</th>
                    <th>Balance</th>
                    <th>Transaccion</th>
                </tr>
                </thead>
                <tbody>
                <input type="hidden" name="count" class="form-control"
                       value="<?php echo e($period); ?>">
                <?php
                $count = 0;
                $principal_balance = $request->principal;
                $balance = $principal_balance;
                $total_principal = 0;
                $total_interest = 0;
                $total_due = 0;
                $next_payment = $request->first_payment_date;
                $due = ($interest_rate * $principal_balance * pow((1 + $interest_rate),
                                        $period)) / (pow((1 + $interest_rate),
                                        $period) - 1);
                for ($i = 1; $i <= $period; $i++) {
                if ($request->interest_method == 'declining_balance_equal_installments') {
                    if ($request->decimal_places == 'round_off_to_two_decimal') {
                        //determine if we have grace period for interest

                        $interest = round(($interest_rate * $balance), 2);
                        $principal = round(($due - $interest), 2);
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest, 2);
                        }
                        $due = round($due, 2);
                        //determine next balance
                        $balance = round(($balance - $principal), 2);
                        $principal_balance = round($balance, 2);
                    } else {
                        //determine if we have grace period for interest

                        $interest = round(($interest_rate * $balance));
                        $principal = round(($due - $interest));
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest);
                        }
                        $due = round($due);
                        //determine next balance
                        $balance = round(($balance - $principal));
                        $principal_balance = round($balance);
                    }


                }
                //reducing balance equal principle
                if ($request->interest_method == 'declining_balance_equal_principal') {
                    $principal = $request->principal / $period;
                    if ($request->decimal_places == 'round_off_to_two_decimal') {

                        $interest = round(($interest_rate * $balance), 2);
                        $principal = round($principal, 2);
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest, 2);
                        }
                        $due = round(($principal + $interest), 2);
                        //determine next balance
                        $balance = round(($balance - ($principal + $interest)), 2);
                        $principal_balance = round($balance, 2);
                    } else {

                        $principal = round(($principal));

                        $interest = round(($interest_rate * $balance));
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest);
                        }
                        $due = round($principal + $interest);
                        //determine next balance
                        $balance = round(($balance - ($principal + $interest)));
                        $principal_balance = round($balance);
                    }

                }
                //interes fijo
                if ($request->interest_method == 'flat_rate') {
                    $principal = $request->principal / $period;
                    if ($request->decimal_places == 'round_off_to_two_decimal') {
                        $interest = round(($interest_rate * $request->principal), 4);
                        $principal = round(($principal), 4);
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest, 4);
                        }
                        $principal = round(($principal), 4);
                        $due = round(($principal + $interest), 4);
                        //determine next balance
                        $balance = round(($balance - $principal), 4);
                        $principal_balance = round($balance, 2);
                    } else {
                        $interest = round(($interest_rate * $request->principal));
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest);
                        }
                        $principal = round($principal);
                        $due = round($principal + $interest);
                        //determine next balance
                        $balance = round(($balance - $principal));
                        $principal_balance = round($balance);
                    }
                }
                //interest only method
                if ($request->interest_method == 'interest_only') {
                    if ($i == $period) {
                        $principal = $request->principal;
                    } else {
                        $principal = 0;
                    }
                    if ($request->decimal_places == 'round_off_to_two_decimal') {
                        $interest = round(($interest_rate * $request->principal), 2);
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest, 2);
                        }
                        $principal = round(($principal), 2);
                        $due = round(($principal + $interest), 2);
                        //determine next balance
                        $balance = round(($balance - $principal), 2);
                        $principal_balance = round($balance, 2);
                    } else {
                        $interest = round(($interest_rate * $request->principal));
                        if ($request->grace_on_interest_charged >= $i) {
                            $interest = 0;
                        } else {
                            $interest = round($interest);
                        }
                        $principal = round($principal);
                        $due = round($principal + $interest);
                        //determine next balance
                        $balance = round(($balance - $principal));
                        $principal_balance = round($balance);
                    }
                }
                $due_date = $next_payment;
                ?>
                <tr>
                    <td>
                        <?php echo e($count+1); ?><input type="hidden" name="collection_idArray[<?php echo e($count); ?>]" class="form-control"
                                           id="inputCollectionId" value="<?php echo e($count); ?>">
                    </td>
                    <td>
                        <?php echo Form::text('due_date['.$count.']',$due_date, array('class' => 'form-control date-picker-schedule','data-date-start-date'=>$request->release_date, 'id'=>"due_date".$count,'readonly'=>"")); ?>

                    </td>
                    <td>
                        <?php echo Form::text('principal['.$count.']',round($principal,2), array('class' => 'form-control','onkeyup'=>"updatesum()",'onkeypress'=>"return isDecimalKey(this,event)", 'id'=>"principal".$count,'readonly'=>"")); ?>

                    </td>
                    
                    <td>
                        <?php echo Form::text('interest['.$count.']',round($interest,2), array('class' => 'form-control','onkeyup'=>"updatesum()",'onkeypress'=>"return isDecimalKey(this,event)", 'id'=>"interest".$count,'readonly'=>"")); ?>

                    </td>
                    
                    <td>
                        <?php echo Form::text('fees['.$count.']','0', array('class' => 'form-control','onkeyup'=>"updatesum()",'onkeypress'=>"return isDecimalKey(this,event)", 'id'=>"fees".$count,'readonly'=>"")); ?>

                    </td>
                    
                    <td>
                        <?php echo Form::text('penalty['.$count.']','0', array('class' => 'form-control','onkeyup'=>"updatesum()",'onkeypress'=>"return isDecimalKey(this,event)", 'id'=>"penalty".$count,'readonly'=>"")); ?>

                    </td>
                    
                    <td>
                        <?php echo Form::text('due['.$count.']',round(($principal+$interest),2), array('class' => 'form-control', 'id'=>"due".$count,'readonly'=>"")); ?>

                    </td>
                    <td>
                        <?php echo Form::text('principal_balance['.$count.']',round($principal_balance,2), array('class' => 'form-control','id'=>"principal_balance".$count,'readonly'=>"")); ?>

                    </td>
                    <td>
                        <?php echo Form::text('description['.$count.']',trans_choice('general.repayment',1), array('class' => 'form-control','id'=>"description".$count,'required'=>'')); ?>

                    </td>
                </tr>
                <?php
                //determine next due date
                if ($request->repayment_cycle == 'daily') {
                    $next_payment = date_format(date_add(date_create($next_payment),
                            date_interval_create_from_date_string('1 days')),
                            'Y-m-d');
                    $due_date = $next_payment;
                }
                if ($request->repayment_cycle == 'weekly') {
                    $next_payment = date_format(date_add(date_create($next_payment),
                            date_interval_create_from_date_string('1 weeks')),
                            'Y-m-d');
                    $due_date = $next_payment;
                }
                if ($request->repayment_cycle == 'monthly') {
                    $next_payment = date_format(date_add(date_create($next_payment),
                            date_interval_create_from_date_string('1 months')),
                            'Y-m-d');
                    $due_date = $next_payment;
                }
                if ($request->repayment_cycle == 'bi_monthly') {
                    $next_payment = date_format(date_add(date_create($request->first_payment_date),
                            date_interval_create_from_date_string('15 days')),
                            'Y-m-d');
                    $due_date = $next_payment;
                }
                if ($request->repayment_cycle == 'quarterly') {
                    $next_payment = date_format(date_add(date_create($next_payment),
                            date_interval_create_from_date_string('2 months')),
                            'Y-m-d');
                    $due_date = $next_payment;
                }
                if ($request->repayment_cycle == 'semi_annually') {
                    $next_payment = date_format(date_add(date_create($next_payment),
                            date_interval_create_from_date_string('6 months')),
                            'Y-m-d');
                    $due_date = $next_payment;
                }
                if ($request->repayment_cycle == 'yearly') {
                    $next_payment = date_format(date_add(date_create($next_payment),
                            date_interval_create_from_date_string('1 years')),
                            'Y-m-d');
                    $due_date = $next_payment;
                }
                if ($i == $period) {
                    $principal_balance = round($balance);
                }
                $total_principal = $total_principal + $principal;
                $total_interest = $interest + $total_interest;
                $total_due = $total_due + $interest + $principal;
                $count++;
                }
                ?>
                <tr>
                    <td>
                    </td>
                    <td>
                        <input type="text" class="form-control" value="Total" readonly="">
                    </td>
                    <td>
                        <input type="text" name="principalTotal" class="form-control"
                               id="principalTotal"
                               value="<?php echo e(round($total_principal,2)); ?>"
                               readonly="">
                    </td>
                    <td>
                        <input type="text" name="interestTotal" class="form-control"
                               id="interestTotal"
                               value="<?php echo e(round($total_interest,2)); ?>"
                               readonly="">
                    </td>
                    <td>
                        <input type="text" name="feesTotal" class="form-control"
                               id="feesTotal"
                               value="0"
                               readonly="">
                    </td>
                    <td>
                        <input type="text" name="penaltyTotal" class="form-control"
                               id="penaltyTotal"
                               value="0"
                               readonly="">
                    </td>
                    <td><!--- Total reporte fin de reporte --->
                        <input type="text" name="inputTotalDueAmountTotal" class="form-control"
                               id="inputTotalDueAmountTotal"
                               value="<?php echo e(round($total_due,2)); ?>"
                               readonly="">
                    </td>
                    <td>
                    </td>
                </tr>
                </tbody>
            </table>



        </div>
        <!-- /.panel-body -->
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatable/media/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/media/js/dataTables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/extensions/Buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script>

        $('#view-repayments').DataTable({
            dom: 'frtip',
            "paging": true,
            "lengthChange": true,
            "displayLength": 15,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true,
            "order": [[0, "asc"]],
            "columnDefs": [
                {"orderable": false, "targets": [4, 5]}
            ],
            "language": {
                "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
                "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
                "info": "<?php echo e(trans('general.info')); ?>",
                "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
                "search": "<?php echo e(trans('general.search')); ?>",
                "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
                "paginate": {
                    "first": "<?php echo e(trans('general.first')); ?>",
                    "last": "<?php echo e(trans('general.last')); ?>",
                    "next": "<?php echo e(trans('general.next')); ?>",
                    "previous": "<?php echo e(trans('general.previous')); ?>"
                }
            },
            responsive: false
        });
    </script>
    <script>
        $('.date-picker-schedule').datepicker({
            orientation: "left",
            autoclose: true,
            format: "yyyy-mm-dd",
            startDate: '<?php echo $request->release_date; ?>'
        });
    </script>
    <script>
        $(document).ready(function (e) {
            $('#interest').text("<?php echo $total_interest; ?>");
            $('#due').text("<?php echo $total_due; ?>");
            $('#total_interest_field').val("<?php echo $total_interest; ?>");
            $('#total_due_field').val("<?php echo $total_due; ?>");
            $('#repayment_cycle').val($('#repayment').text());
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>