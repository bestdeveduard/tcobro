
<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.capital',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title"><?php echo e(trans_choice('general.capital',2)); ?> <?php echo e(trans_choice('general.transaction',2)); ?></h2>

      <div class="heading-elements">
        <?php if(Sentinel::hasAccess('capital.create')): ?>
        <a href="<?php echo e(url('capital/create')); ?>" class="btn btn-info btn-sm"><?php echo e(trans_choice('general.add',1)); ?>

          <?php echo e(trans_choice('general.capital',1)); ?></a>
        <?php endif; ?>
      </div>
    </div>
    <div class="panel-body ">
      <div class="table-responsive">
        <table id="order-listing" class="table">
          <thead>
            <tr>
              <th><?php echo e(trans_choice('general.account',1)); ?></th>
              <th><?php echo e(trans_choice('general.amount',1)); ?></th>
              <th><?php echo e(trans_choice('general.date',1)); ?></th>
              <th><?php echo e(trans_choice('general.description',1)); ?></th>
              <th><?php echo e(trans_choice('general.action',1)); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php if(!empty($key->debit_chart)): ?>
                <?php echo e($key->debit_chart->name); ?>

                <?php endif; ?>
              </td>
              <td>
                <?php echo e($key->amount); ?>

              </td>
              <td><?php echo e($key->date); ?></td>
              <td><?php echo e($key->notes); ?></td>
              <td>
                <a href="<?php echo e(url('capital/'.$key->id.'/edit')); ?>"><img
                    src="https://img.icons8.com/cute-clipart/64/000000/edit.png" /></a>
                <a href="<?php echo e(url('capital/'.$key->id.'/delete')); ?>"><img
                    src="https://img.icons8.com/flat_round/64/000000/delete-sign.png" /></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    <!-- /.panel-body -->
  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<script>
$('#data-table').DataTable({
  "paging": true,
  "lengthChange": true,
  "displayLength": 15,
  "searching": true,
  "ordering": true,
  "info": true,
  "autoWidth": true,
  "order": [
    [2, "desc"]
  ],
  "columnDefs": [{
    "orderable": false,
    "targets": [4]
  }],
  "language": {
    "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
    "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
    "info": "<?php echo e(trans('general.info')); ?>",
    "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
    "search": "<?php echo e(trans('general.search')); ?>",
    "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
    "paginate": {
      "first": "<?php echo e(trans('general.first')); ?>",
      "last": "<?php echo e(trans('general.last')); ?>",
      "next": "<?php echo e(trans('general.next')); ?>",
      "previous": "<?php echo e(trans('general.previous')); ?>"
    }
  },
  responsive: false
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>