
<?php $__env->startSection('title'); ?><?php echo e(trans_choice('general.charge',2)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-white">
        <div class="panel-heading">
            <h6 class="panel-title"><?php echo e(trans_choice('general.charge',2)); ?></h6>

            <div class="heading-elements">
                <a href="<?php echo e(url('charge/create')); ?>"
                   class="btn btn-info btn-sm"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.charge',1)); ?></a>
            </div>
        </div>
        <div class="panel-body">
            <table id="" class="table table-striped table-condensed table-hover basic-datatable">
                <thead>
                <tr>
                    <th><?php echo e(trans_choice('general.name',1)); ?></th>
                    <th><?php echo e(trans_choice('general.product',1)); ?></th>
                    <th><?php echo e(trans_choice('general.type',1)); ?></th>
                    <th><?php echo e(trans_choice('general.active',1)); ?></th>
                    <th><?php echo e(trans_choice('general.amount',1)); ?></th>
                    <th><?php echo e(trans_choice('general.action',1)); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key->name); ?></td>
                        <td>
                            <?php if($key->product=='loan'): ?>
                                <?php echo e(trans_choice('general.loan',1)); ?>

                            <?php endif; ?>
                            <?php if($key->product=='savings'): ?>
                                <?php echo e(trans_choice('general.saving',2)); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($key->charge_type=='disbursement'): ?>
                                <?php echo e(trans_choice('general.disbursement',1)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='specified_due_date'): ?>
                                <?php echo e(trans_choice('general.specified_due_date',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='installment_fee'): ?>
                                <?php echo e(trans_choice('general.installment_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='overdue_installment_fee'): ?>
                                <?php echo e(trans_choice('general.overdue_installment_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='loan_rescheduling_fee'): ?>
                                <?php echo e(trans_choice('general.loan_rescheduling_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='overdue_maturity'): ?>
                                <?php echo e(trans_choice('general.overdue_maturity',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='savings_activation'): ?>
                                <?php echo e(trans_choice('general.savings_activation',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='withdrawal_fee'): ?>
                                <?php echo e(trans_choice('general.withdrawal_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='monthly_fee'): ?>
                                <?php echo e(trans_choice('general.monthly_fee',2)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_type=='annual_fee'): ?>
                                <?php echo e(trans_choice('general.annual_fee',2)); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($key->active==1): ?>
                                <?php echo e(trans_choice('general.active',1)); ?>

                            <?php else: ?>
                                <?php echo e(trans_choice('general.inactive',1)); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo e($key->amount); ?>

                            <?php if($key->charge_option=="fixed"): ?>
                                <?php echo e(trans_choice('general.fixed',1)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_option=="principal_due"): ?>
                                % <?php echo e(trans_choice('general.principal',1)); ?> <?php echo e(trans_choice('general.due',1)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_option=="principal_interest"): ?>
                                % <?php echo e(trans_choice('general.principal',1)); ?> + <?php echo e(trans_choice('general.interest',1)); ?> <?php echo e(trans_choice('general.due',1)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_option=="interest_due"): ?>
                                % <?php echo e(trans_choice('general.interest',1)); ?> <?php echo e(trans_choice('general.due',1)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_option=="total_due"): ?>
                                % <?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.due',1)); ?>

                            <?php endif; ?>
                            <?php if($key->charge_option=="original_principal"): ?>
                                % <?php echo e(trans_choice('general.original',1)); ?> <?php echo e(trans_choice('general.principal',1)); ?>

                            <?php endif; ?>

                        </td>
                        <td>
                            <ul class="icons-list">
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="icon-menu9"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right" role="menu">
                                        <li><a href="<?php echo e(url('charge/'.$key->id.'/edit')); ?>"><i
                                                        class="fa fa-edit"></i> <?php echo e(trans('general.edit')); ?> </a></li>
                                        <li><a href="<?php echo e(url('charge/'.$key->id.'/delete')); ?>"
                                               class="delete"><i
                                                        class="fa fa-trash"></i> <?php echo e(trans('general.delete')); ?> </a></li>
                                    </ul>
                                </li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>