<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.product',1)); ?> <?php echo e(trans_choice('general.summary',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title">
        Indique la fecha de revision
        <?php if(!empty($end_date)): ?>
        : <b><?php echo e($start_date); ?> al <?php echo e($end_date); ?></b>
        <?php endif; ?>
      </h2>

      <div class="heading-elements">

      </div>
    </div>
    <div class="panel-body hidden-print">
      <?php echo Form::open(array('url' => Request::url(), 'method' => 'post','class'=>'form-horizontal', 'name' => 'form')); ?>

      <div class="row">
        <div class="col-md-2">
          <?php echo Form::label('start_date',trans_choice('general.date',1).'
          '.trans_choice('general.start',1),array('class'=>'')); ?>

          <?php echo Form::date('start_date',$start_date, array('class' => 'form-control date-picker',
          'placeholder'=>"",'required'=>'required')); ?>

        </div>
        <div class="col-md-2">
          <?php echo Form::label('end_date',trans_choice('general.date',1).'
          '.trans_choice('general.end',1),array('class'=>'')); ?>

          <?php echo Form::date('end_date',$end_date, array('class' => 'form-control date-picker',
          'placeholder'=>"",'required'=>'required')); ?>

        </div>
      </div>
      <br>
      
      <div class="panel-body">
        <div class="row">
          <div class="col-md-12">

            <button type="submit" class="btn btn-success"><?php echo e(trans_choice('general.search',1)); ?>!
            </button>


            <a href="<?php echo e(Request::url()); ?>" class="btn btn-danger"><?php echo e(trans_choice('general.reset',1)); ?>!</a>

            <div class="btn-group">
              <button type="button" class="btn dropdown-toggle legitRipple"
                data-toggle="dropdown"><?php echo e(trans_choice('general.download',1)); ?> <?php echo e(trans_choice('general.report',1)); ?>

                </button>
              <ul class="dropdown-menu dropdown-menu-right">
                <li>
                  <a href="<?php echo e(url('report/company_report/products_summary/pdf?start_date='.$start_date.'&end_date='.$end_date)); ?>"
                    target="_blank" style="font-size: 13px; margin-top: 5px; padding: 0 10px;"><i class="icon-file-pdf"></i> <span style="position: relative; top: -6px;"><?php echo e(trans_choice('general.download',1)); ?>

                    <?php echo e(trans_choice('general.to',1)); ?> <?php echo e(trans_choice('general.pdf',1)); ?></span>
                  </a>
                </li>
                <li>
                  <a href="<?php echo e(url('report/company_report/products_summary/excel?start_date='.$start_date.'&end_date='.$end_date)); ?>"
                    target="_blank" style="font-size: 13px; margin-top: 5px; padding: 0 10px;"><i class="icon-file-excel"></i> <span style="position: relative; top: -6px;"><?php echo e(trans_choice('general.download',1)); ?>

                    <?php echo e(trans_choice('general.to',1)); ?> <?php echo e(trans_choice('general.excel',1)); ?></span>
                  </a>
                </li>
                <li>
                  <!---<a href="<?php echo e(url('report/company_report/products_summary/csv?start_date='.$start_date.'&end_date='.$end_date)); ?>"
                                       target="_blank"><i
                                                class="icon-download"></i> <?php echo e(trans_choice('general.download',1)); ?> <?php echo e(trans_choice('general.to',1)); ?> <?php echo e(trans_choice('general.csv',1)); ?>

                                    </a>--->
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <?php echo Form::close(); ?>


    </div>
    <!-- /.panel-body -->
  </div>

  <!-- /.box -->
  <?php if(!empty($end_date)): ?>
  <div class="card-body">
    <div class="panel-body table-responsive no-padding">

      <table id="order-listing" class="table">
        <thead>
          <tr>
            <th></th>
            <th colspan="5"><?php echo e(trans_choice('general.total',1)); ?> <?php echo e(trans_choice('general.disbursed',1)); ?></th>
            <th colspan="5">Distribucion General</th>
          </tr>
          <tr>
            <th><?php echo e(trans_choice('general.name',1)); ?></th>
            <th><?php echo e(trans_choice('general.loan',2)); ?></th>
            <th><?php echo e(trans_choice('general.principal',1)); ?></th>
            <th><?php echo e(trans_choice('general.interest',1)); ?></th>
            <th><?php echo e(trans_choice('general.fee',2)); ?></th>
            <th><?php echo e(trans_choice('general.total',1)); ?></th>
            <th><?php echo e(trans_choice('general.principal',1)); ?></th>
            <th><?php echo e(trans_choice('general.interest',1)); ?></th>
            <th><?php echo e(trans_choice('general.fee',2)); ?></th>
            <th><?php echo e(trans_choice('general.penalty',1)); ?></th>
            <th><?php echo e(trans_choice('general.total',1)); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php
                    $total_disbursed = 0;
                    $total_disbursed_loans = 0;
                    $total_disbursed_principal = 0;
                    $total_disbursed_interest = 0;
                    $total_disbursed_fees = 0;
                    $total_disbursed_penalty = 0;
                    $total_outstanding = 0;
                    $total_outstanding_principal = 0;
                    $total_outstanding_interest = 0;
                    $total_outstanding_fees = 0;
                    $total_outstanding_penalty = 0;

                    ?>
          <?php $__currentLoopData = \App\Models\LoanProduct::where('user_id', Sentinel::getUser()->business_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
                        $principal_disbursed = 0;
                        $interest_disbursed = 0;
                        $fees_disbursed = 0;
                        $penalty_disbursed = 0;
                        $principal_outstanding = 0;
                        $interest_outstanding = 0;
                        $fees_outstanding = 0;
                        $penalty_outstanding = 0;
                        $disbursed_loans = 0;
                        $disbursed = 0;
                        $outstanding = 0;
                        //loop through loans, this will need to be improved
                        foreach (\App\Models\Loan::where('loan_product_id', $key->id)->where('branch_id',
                        Sentinel::getUser()->business_id)->whereIn('status',
                            ['disbursed', 'closed', 'written_off'])->whereBetween('release_date',
                            [$start_date, $end_date])->get() as $loan) {
                            $disbursed_loans = $disbursed_loans + 1;
                            $loan_due_items = \App\Helpers\GeneralHelper::loan_due_items($key->id);
                            $loan_paid_items = \App\Helpers\GeneralHelper::loan_paid_items($key->id);
                            $principal_disbursed =$principal_disbursed+ $loan_due_items["principal"];
                            $interest_disbursed =$interest_disbursed+ $loan_due_items["interest"];
                            $fees_disbursed =$fees_disbursed+ $loan_due_items["fees"];
                            $penalty_disbursed =$penalty_disbursed+ $loan_due_items["penalty"];
                            $principal_outstanding =$principal_outstanding+ $loan_due_items["principal"] - $loan_paid_items["principal"];
                            $interest_outstanding =$interest_outstanding+ $loan_due_items["interest"] - $loan_paid_items["interest"];
                            $fees_outstanding =$fees_outstanding+ $loan_due_items["fees"] - $loan_paid_items["fees"];
                            $penalty_outstanding =$penalty_outstanding+ $loan_due_items["penalty"] - $loan_paid_items["penalty"];
                        }
                        $disbursed = $principal_disbursed + $interest_disbursed + $fees_disbursed;
                        $outstanding = $principal_outstanding + $interest_outstanding + $fees_outstanding + $penalty_outstanding;
                        $total_disbursed = $total_disbursed + $disbursed;
                        $total_disbursed_loans = $total_disbursed_loans + $disbursed_loans;
                        $total_disbursed_principal = $total_disbursed_principal + $principal_disbursed;
                        $total_disbursed_interest = $total_disbursed_interest + $interest_disbursed;
                        $total_disbursed_fees = $total_disbursed_fees + $fees_disbursed;
                        $total_disbursed_penalty = $total_disbursed_penalty + $penalty_disbursed;
                        $total_outstanding_principal = $total_outstanding_principal + $principal_outstanding;
                        $total_outstanding_interest = $total_outstanding_interest + $interest_outstanding;
                        $total_outstanding_fees = $total_outstanding_fees + $fees_outstanding;
                        $total_outstanding_penalty = $total_outstanding_penalty + $penalty_outstanding;
                        $total_outstanding = $total_outstanding + $principal_outstanding + $interest_outstanding + $fees_outstanding + $penalty_outstanding;

                        ?>
          <tr>
            <td><?php echo e($key->name); ?></td>
            <td><?php echo e($disbursed_loans); ?></td>
            <td><?php echo e(number_format($principal_disbursed,2)); ?></td>
            <td><?php echo e(number_format($interest_disbursed,2)); ?></td>
            <td><?php echo e(number_format($fees_disbursed,2)); ?></td>
            <td><?php echo e(number_format($disbursed,2)); ?></td>
            <td><?php echo e(number_format($principal_outstanding,2)); ?></td>
            <td><?php echo e(number_format($interest_outstanding,2)); ?></td>
            <td><?php echo e(number_format($fees_outstanding,2)); ?></td>
            <td><?php echo e(number_format($penalty_outstanding,2)); ?></td>
            <td><?php echo e(number_format($outstanding,2)); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
          <tr>
            <th></th>
            <td><?php echo e($total_disbursed_loans); ?></td>
            <td><?php echo e(number_format($total_disbursed_principal,2)); ?></td>
            <td><?php echo e(number_format($total_disbursed_interest,2)); ?></td>
            <td><?php echo e(number_format($total_disbursed_fees,2)); ?></td>
            <td><?php echo e(number_format($total_disbursed,2)); ?></td>
            <td><?php echo e(number_format($total_outstanding_principal,2)); ?></td>
            <td><?php echo e(number_format($total_outstanding_interest,2)); ?></td>
            <td><?php echo e(number_format($total_outstanding_fees,2)); ?></td>
            <td><?php echo e(number_format($total_outstanding_penalty,2)); ?></td>
            <td><?php echo e(number_format($total_outstanding,2)); ?></td>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
  <script>
  $(document).ready(function() {
    $("body").addClass('sidebar-xs');
  });
  </script>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>