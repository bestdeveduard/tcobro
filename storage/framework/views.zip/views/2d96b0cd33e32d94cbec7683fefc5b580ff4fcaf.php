<?php $__env->startSection('title'); ?>
Detalle de prestamo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($loan->borrower->blacklisted==1): ?>
<div class="row">
  <div class="col-sm-12">
    <div class="alert bg-danger"><?php echo e(trans_choice('general.blacklist_notification',1)); ?></div>
  </div>
</div>
<?php endif; ?>
<div class="card">

  <div class="row">
    <div class="col-md-12">
      <div class="border-left-primary" style="padding: 15px 16px;">
        <div class="panel-heading">
          <h6 class="panel-title">Perfil del Cliente</h6>

          <div class="heading-elements">

          </div>
        </div>

        <div class="panel-body">
          <div class="row">
            <div class="col-md-2">
              <?php if(!empty($loan->borrower->photo)): ?>
              <a href="<?php echo e(asset('uploads/'.$loan->borrower->photo)); ?>" class="fancybox"> <img class="img-thumbnail"
                  src="<?php echo e(asset('uploads/'.$loan->borrower->photo)); ?>" alt="user image" style="max-height: 150px" /></a>
              <?php else: ?>
              <img class="img-thumbnail" src="<?php echo e(asset('assets/dist/img/user.png')); ?>" alt="user image"
                style="max-height: 150px" />
              <?php endif; ?>
            </div>

            <div class="col-md-3 form-horizontal">
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Nombre Cliente
                    :</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <span><?php echo e($loan->borrower->title); ?> <?php echo e($loan->borrower->first_name); ?> <?php echo e($loan->borrower->last_name); ?></span>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Codigo Referencia
                    :</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <span>#<?php echo e($loan->borrower->id); ?></span>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Genero
                    :</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <?php if($loan->borrower->gender=="Male"): ?>
                  <span class=""><?php echo e(trans_choice('general.male',1)); ?></span>
                  <?php endif; ?>
                  <?php if($loan->borrower->gender=="Female"): ?>
                  <span class=""><?php echo e(trans_choice('general.female',1)); ?></span>
                  <?php endif; ?>
                </div>
              </div>

            </div>
            <div class="col-md-3 form-horizontal">
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Edad
                    :</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <?php if($loan->borrower->dob): ?>
                  <span><?php echo e(date("Y-m-d")-$loan->borrower->dob); ?> <?php echo e(trans_choice('general.year',2)); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Telefono:</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <span> <a href="<?php echo e(url('communication/sms/create?borrower_id='.$loan->borrower->id)); ?>">
                      <?php echo e($loan->borrower->mobile); ?></a></span>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Correo Electronico
                    :</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <span> <a
                      href="<?php echo e(url('communication/email/create?borrower_id='.$loan->borrower->id)); ?>"><?php echo e($loan->borrower->email); ?></a></span>
                </div>
              </div>

            </div>
            <div class="col-md-3 form-horizontal">
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Empresa donde labora
                    :</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <span><?php echo e($loan->borrower->business_name); ?></span>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-4"><strong>Direccion donde reside:</strong></label>
                <div class="col-md-8" style="padding-top: 9px;">
                  <span><?php echo e($loan->borrower->address); ?></span>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-4"><strong>Pais de residencia:</strong></label>
                <div class="col-sm-8" style="padding-top: 9px;">
                  <?php if($loan->borrower->country): ?>
                  <span><?php echo e($loan->borrower->country->name); ?></span>
                  <?php endif; ?>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="panel-footer panel-footer-condensed"><a class="heading-elements-toggle"><i
              class="icon-more"></i></a>
          <div class="heading-elements">
            <span class="heading-text">Fecha de Creacion:
              <?php
                $fecha_creacion_cliente = $loan->borrower->created_at;
                $timestamp = strtotime($fecha_creacion_cliente);
                $fecha_creacion_cliente2 = date("d-m-Y", $timestamp);
                ?>
            <span class="text-semibold"><?php echo e($fecha_creacion_cliente2); ?></span></span>            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<br>
<div class="card">
  <div class="row">
    <div class="col-md-12">
      <!-- Custom Tabs -->
      <div class="panel-white">
        <div class="card-body">
          <ul class="nav nav-tabs" role="tablist">
            <?php if($loan->status=="disbursed" || $loan->status=="closed" || $loan->status=="withdrawn" ||
            $loan->status=="written_off" || $loan->status=="rescheduled" ): ?>
            <li class="nav-item"><a class="nav-link" href="#transactions" data-toggle="tab"
                aria-expanded="true"><strong>HISTORIAL DE TRANSACCIONES</strong></a></li>
            <li class="nav-item"><a class="nav-link" href="#loan_schedule" data-toggle="tab"
                aria-expanded="false"><strong>CALENDARIO DE PAGO</strong></a></li>
            <li class="nav-item"><a class="nav-link" href="#pending_dues" data-toggle="tab"
                aria-expanded="false"><strong>RESUMEN DE BALANCES</strong></a>
            </li>

            <?php endif; ?>
            <li class="nav-item active"><a class="nav-link active" href="#loan_terms" data-toggle="tab"
                aria-expanded="false"><strong>INFORMACION</strong></a>
            </li>

            <!-- <li class="nav-item"><a class="nav-link" href="#loan_collateral" data-toggle="tab"
                                        aria-expanded="false"><strong>GARANTIAS</strong></a>
                        </li> -->
            <li class="nav-item"><a class="nav-link" href="#loan_guarantors" data-toggle="tab"
                aria-expanded="false"><strong>GARANTE</strong></a>
            </li>
            <li class="nav-item"><a class="nav-link" href="#loan_files" data-toggle="tab"
                aria-expanded="false"><strong>DOCUMENTOS</strong></a>
            </li>
            <li class="nav-item"><a class="nav-link" href="#loan_comments" data-toggle="tab"
                aria-expanded="false"><strong>OBSERVACIONES</strong></a>
            </li>
          </ul>

          <div class="tab-content">
            <?php if($loan->status=="disbursed" || $loan->status=="closed" || $loan->status=="withdrawn" ||
            $loan->status=="written_off" || $loan->status=="rescheduled" ): ?>
            <!-- /.tab-pane -->
            <div class="tab-pane " id="transactions">
              <div class="btn-group-horizontal">
                <?php if(Sentinel::hasAccess('repayments.create')): ?>
                <a type="button" class="btn btn-info m-10"
                  href="<?php echo e(url('loan/'.$loan->id.'/repayment/create')); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                  <?php echo e(trans_choice('general.repayment',1)); ?></a>
                <?php endif; ?>
              </div>
              <div class="box box-info">
                <div class="panel-body">
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="table-responsive">
                        <table id="order-listing" class="table">
                          <thead>
                            <tr>
                              <th>
                                Referencia
                              </th>
                              <th>
                                Fecha Efectiva
                              </th>
                              <th>
                                Fecha Procesamiento
                              </th>
                              <th>
                                Tipo de Transaccion
                              </th>

                              <th style="display: none;">
                                Debito
                              </th>
                              <th style="display: none;">
                                Credito
                              </th>
                              <th>
                                Monto
                              </th>
                              <th>
                                Balance
                              </th>
                              <th>
                                Referencias
                              </th>
                              <th class="text-center">
                                <?php echo e(trans_choice('general.action',1)); ?>

                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $balance = 0;
                            ?>
                            <?php $__currentLoopData = \App\Models\LoanTransaction::where('loan_id',$loan->id)->whereIn('reversal_type',['user','none'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                            $balance = $balance + ($key->debit - $key->credit);
                            ?>
                            <tr>
                              <td><?php echo e($key->id); ?></td>
                              <td>
                                <?php
                                $date_history = $key->date;
                                $timestamp = strtotime($date_history);
                                $fecha_historica = date("d-m-Y", $timestamp);
                                ?>
                                <?php echo e($fecha_historica); ?>

                              </td>
                              <td>
                                <?php
                                $date_process = $key->created_at;
                                $timestamp = strtotime($date_process);
                                $fecha_procesamiento = date("d-m-Y", $timestamp);
                                ?>

                                <?php echo e($fecha_procesamiento); ?></td>

                              <td>
                                <?php if($key->transaction_type=='disbursement'): ?>
                                Capital
                                <?php endif; ?>
                                <?php if($key->transaction_type=='specified_due_date_fee'): ?>

                                <?php if($key->notes==""): ?>
                                <?php echo e(trans_choice("Ajuste de Saldo (+)",2)); ?>

                                <?php else: ?>
                                <?php echo e($key->notes); ?>

                                <?php endif; ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type==''): ?>
                                Reduccion de saldo (-)
                                <?php endif; ?>
                                <?php if($key->transaction_type=='installment_fee'): ?>
                                <?php echo e(trans_choice('general.installment_fee',2)); ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type=='overdue_installment_fee'): ?>
                                <?php echo e(trans_choice('general.overdue_installment_fee',2)); ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type=='loan_rescheduling_fee'): ?>
                                <?php echo e(trans_choice('general.loan_rescheduling_fee',2)); ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type=='overdue_maturity'): ?>
                                <?php echo e(trans_choice('general.overdue_maturity',2)); ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type=='disbursement_fee'): ?>
                                <?php echo e(trans_choice('general.disbursement',1)); ?> <?php echo e(trans_choice('general.charge',2)); ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type=='interest'): ?>
                                Interes <?php echo e(number_format($loan->interest_rate,2)); ?>% /
                                <?php if($loan->interest_period=='daily'): ?>
                                Diario
                                <?php endif; ?>
                                <?php if($loan->interest_period=='weekly'): ?>
                                Semanal
                                <?php endif; ?>
                                <?php if($loan->interest_period=='month'): ?>
                                Mensual
                                <?php endif; ?>
                                <?php if($loan->interest_period=='bi_monthly'): ?>
                                Quincenal
                                <?php endif; ?>
                                <?php if($loan->interest_period=='quarterly'): ?>
                                <?php echo e(trans_choice('general.quarterly',1)); ?>

                                <?php endif; ?>
                                <?php if($loan->interest_period=='semi_annual'): ?>
                                <?php echo e(trans_choice('general.semi_annually',1)); ?>

                                <?php endif; ?>
                                <?php if($loan->interest_period=='annually'): ?>
                                <?php echo e(trans_choice('general.annual',1)); ?>

                                <?php endif; ?>
                                <?php endif; ?>
                                <?php if($key->transaction_type=='repayment'): ?>
                                Pago
                                <?php endif; ?>
                                <?php if($key->transaction_type=='penalty'): ?>
                                Mora
                                <?php endif; ?>
                                <?php if($key->transaction_type=='interest_waiver'): ?>
                                <?php echo e(trans_choice('general.interest',1)); ?> <?php echo e(trans_choice('general.waiver',2)); ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type=='waiver'): ?>
                                Ajuste
                                <?php endif; ?>
                                <?php if($key->transaction_type=='charge_waiver'): ?>
                                <?php echo e(trans_choice('general.charge',1)); ?> <?php echo e(trans_choice('general.waiver',2)); ?>

                                <?php endif; ?>
                                <?php if($key->transaction_type=='write_off'): ?>
                                Balance Castigado
                                <?php endif; ?>
                                <?php if($key->transaction_type=='write_off_recovery'): ?>
                                Pago de recuperacion
                                <?php endif; ?>
                                <?php if($key->reversed==1): ?>
                                <?php if($key->reversal_type=="user"): ?>
                                <span class="text-danger"><b>(Anulado)</b></span>
                                <?php endif; ?>
                                <?php if($key->reversal_type=="system"): ?>
                                <span class="text-danger"><b>(Anulado)</b></span>
                                <?php endif; ?>
                                <?php endif; ?>
                              </td>
                              <td style="display: none;"><?php echo e(number_format($key->debit,2)); ?></td>
                              <td style="display: none;"><?php echo e(number_format($key->credit,2)); ?></td>
                              <?php
                                $value_credit = $key->credit;
                                $value_debit = $key->debit;
                                $value_amount_trxn = abs($value_debit - $value_credit);
                                ?>
                              <td><strong><?php echo e(number_format($value_amount_trxn,2)); ?></strong></td>
                              <td><strong><?php echo e(number_format($balance,2)); ?></strong></td>
                              <td><?php echo e($key->receipt); ?></td>
                              <td class="text-center">
                                <ul class="icons-list">
                                  <li class="dropdown">
                                    <a href="#" data-toggle="dropdown">
                                      <img src="https://img.icons8.com/pastel-glyph/25/000000/plus.png" />
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right">
                                      <li>
                                        <a href="<?php echo e(url('loan/transaction/'.$key->id.'/show')); ?>"><i
                                            class="fa fa-search"></i> Visualizar
                                        </a>
                                      </li>
                                      <li>

                                        <?php if($key->transaction_type=='repayment' && $key->reversible==1): ?>
                                      <li>
                                        <a href="<?php echo e(url('loan/transaction/'.$key->id.'/print')); ?>" target="_blank"><i
                                            class="icon-printer"></i> Imprimir recibo
                                        </a>
                                      </li>
                                      <li>
                                        <a href="<?php echo e(url('loan/transaction/'.$key->id.'/pdf')); ?>" target="_blank"><i
                                            class="icon-file-pdf"></i> Descargar recibo
                                        </a>
                                      </li>
                                      <?php if(Sentinel::hasAccess('repayments.delete')): ?>
                                      <li>
                                        <a href="<?php echo e(url('loan/repayment/'.$key->id.'/edit')); ?>"><i class="fa fa-edit"></i>
                                          Modificar pago
                                        </a>
                                      </li>
                                      <li>
                                        <a href="<?php echo e(url('loan/repayment/'.$key->id.'/reverse')); ?>" class="delete"><i
                                            class="fa fa-minus-circle"></i> Reversar pago
                                        </a>
                                      </li>
                                      <?php endif; ?>
                                      <?php endif; ?>
                                      <?php if($key->transaction_type=='penalty' && $key->reversible==1): ?>
                                      <li>
                                        <a href="<?php echo e(url('loan/transaction/'.$key->id.'/waive')); ?>" class="delete"><i
                                            class="fa fa-minus-circle"></i> <?php echo e(trans('general.waive')); ?>

                                        </a>
                                      </li>
                                      <?php endif; ?>
                                      <?php if($key->transaction_type=='installment_fee' && $key->reversible==1): ?>
                                      <li>
                                        <a href="<?php echo e(url('loan/transaction/'.$key->id.'/waive')); ?>" class="delete"><i
                                            class="fa fa-minus-circle"></i> <?php echo e(trans('general.waive')); ?>

                                        </a>
                                      </li>
                                      <?php endif; ?>
                                      <?php if($key->transaction_type=='specified_due_date_fee' && $key->reversible==1): ?>
                                      <li>
                                        <a href="<?php echo e(url('loan/transaction/'.$key->id.'/waive')); ?>" class="delete"><i
                                            class="fa fa-minus-circle"></i> <?php echo e(trans('general.waive')); ?>

                                        </a>
                                      </li>
                                      <?php endif; ?>
                                    </ul>
                                  </li>
                                </ul>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.tab-pane -->
            <!-- /.tab-pane -->
            <div class="tab-pane" id="loan_schedule">
              <div class="row">
                <div class="col-sm-3">

                  <div class="input-group-btn">
                    <button type="button" class="btn btn-info dropdown-toggle m-10" data-toggle="dropdown"
                      aria-expanded="false">Mas opciones
                      <span class="fa fa-caret-down"></span></button>
                    <ul class="dropdown-menu" role="menu">
                      <li>
                        <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/print')); ?>" target="_blank">Imprimir</a>
                      </li>
                      <li>
                        <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/pdf')); ?>" target="_blank">Descargar en PDF</a>
                      </li>
                      <?php if(Sentinel::hasAccess('communication.create')): ?>
                      <li>
                        <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/email')); ?>">Enviar por correo</a>
                      </li>
                      <?php endif; ?>
                      <li>
                        <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/excel')); ?>" target="_blank">Descargar en Excel</a>
                      </li>

                      <!---<li>
                                            <a href="<?php echo e(url('loan/'.$loan->id.'/schedule/csv')); ?>"
                                               target="_blank">Download in CSV</a></li>--->
                    </ul>
                  </div>
                </div>
              </div>
              <div class="box box-success">
                <div class="panel-body table-responsive no-padding">
                  <table id="order-listing" class="table">
                    <tbody>
                      <tr>
                        <th style="width: 10px">
                          <b>#</b>
                        </th>
                        <th>
                          <b>Fecha</b>
                        </th>
                        <th style="text-align:right;">
                          <b>Recibido</b>
                        </th>
                        <th>
                          <b>Transaccion</b>
                        </th>
                        <th style="">
                          <b>Capital</b>
                        </th>
                        <th style="text-align:right;">
                          <b>Interes</b>
                        </th>
                        <th style="text-align:right;">
                          <b>Cargos</b>
                        </th>
                        <th style="text-align:right;">
                          <b>Mora</b>
                        </th>

                        <th style="text-align:right;">
                          <b>Total</b>
                        </th>
                        <th style="text-align:right;">
                          <b>Pagado</b>
                        </th>
                        <th style="text-align:right;">
                          <b>Pendiente</b>
                        </th>
                        <th style="text-align:right;">
                          <b>Balance</b>
                        </th>
                      </tr>
                      <?php
                        //check for disbursement charges
                        $disbursement_charges = \App\Models\LoanTransaction::where('loan_id',
                            $loan->id)->where('transaction_type',
                            'disbursement_fee')->where('reversed', 0)->sum('debit');
                        ?>
                      <tr>
                        <td></td>
                        <td>
                          <!---Fecha desembolso prestamos--->
                          <?php echo e($loan->release_date); ?>

                        </td>
                        <td></td>
                        <td>
                          <!---Descripcion transaccion principal--->
                          <?php echo e(trans_choice('general.disbursement',1)); ?>

                        </td>
                        <td></td>
                        <td></td>
                        <td style="text-align:right;">
                          <?php if(!empty($disbursement_charges)): ?>
                          <b><?php echo e(number_format($disbursement_charges,2)); ?></b>
                          <?php endif; ?>
                        </td>
                        <td></td>
                        <td style="text-align:right;">
                          <?php if(!empty($disbursement_charges)): ?>
                          <b><?php echo e(number_format($disbursement_charges,2)); ?></b>
                          <?php endif; ?>
                        </td>
                        <td style="text-align:right;">
                          <?php if(!empty($disbursement_charges)): ?>
                          <b><?php echo e(number_format($disbursement_charges,2)); ?></b>
                          <?php endif; ?>
                        </td>
                        <td>
                        </td>

                        <?php
                            $totalPrincipal = \App\Models\LoanSchedule::where('loan_id',
                            $loan->id)->sum('principal');
                            $payPrincipal = \App\Models\LoanTransaction::where('loan_id', $loan->id)->where('transaction_type', 'repayment')->where('reversed', 0)->where('payment_type', 'principal')->sum('credit');
                            $balancePrincipal = $totalPrincipal - $payPrincipal;
                        ?>

                        <td style="text-align:right;">
                          <?php echo e(number_format($balancePrincipal,2)); ?>

                        </td>
                      </tr>
                      <?php
                                           
                        $timely = 0;
                        $total_overdue = 0;
                        $overdue_date = "";
                        $total_till_now = 0;
                        $count = 1;
                        $total_due = 0;
                        $principal_balance = $balancePrincipal;
                        $payments = \App\Models\LoanTransaction::where('loan_id', $loan->id)->where('transaction_type', 'repayment')->where('reversed', 0)->where('payment_type', 'regular')->sum('credit');
                        $total_paid = $payments;
                        $next_payment = [];
                        $next_payment_amount = "";
                        $totalPrincipal = 0;
                        $totalInterest = 0;
                        $loans_type = $loan->repayment_cycle;
                        
                        foreach ($loan->schedules as $schedule) {
                            $schedule_count = count($loan->schedules);
                            $principal = $balancePrincipal / $schedule_count;
                            $cuotas = $loan->loan_duration;
                            $loanRate = $loan->interest_rate;

                            if ($loan->repayment_cycle=='daily') {
                            $interest = (($balancePrincipal * $loanRate) / 100.00) / 30;

                            } elseif ($loan->repayment_cycle=='weekly') {
                            $interest = (($balancePrincipal * $loanRate) / 100.00) / 4;

                            } elseif ($loan->repayment_cycle=='bi_monthly') {
                            $interest = (($balancePrincipal * $loanRate) / 100.00) / 2;

                            } elseif ($loan->repayment_cycle=='monthly') {
                            $interest = ($balancePrincipal * $loanRate) / 100.00;        
                            } else {
                            $interest = 0;
                        }

                        // ***CALCULO INTERES***
                        $principal_balance = $principal_balance - $principal;
                        $totalPrincipal += $principal;
                        $totalInterest += $interest;
                                            
                        $due = $principal + $interest + $schedule->fees + $schedule->penalty- $schedule->interest_waived;
                        $total_due = $total_due + ($principal + $interest + $schedule->fees + $schedule->penalty - $schedule->interest_waived);
                                            
                                            
                        $paid = 0;
                        $paid_by = '';
                        $overdue = 0;
                        
                        if ($payments > 0) {
                            if ($payments > $due) {
                                $paid = $due;
                                $payments = $payments - $due;
                                //find the corresponding paid by date
                                $p_paid = 0;
                                foreach (\App\Models\LoanTransaction::where('loan_id',
                                    $loan->id)->where('transaction_type',
                                    'repayment')->where('reversed', 0)->orderBy('date',
                                    'asc')->get() as $key) {
                                    $p_paid = $p_paid + $key->credit;
                                    if ($p_paid >= $total_due) {
                                        $paid_by = $key->date;
                                        if ($key->date > $schedule->due_date && date("Y-m-d") > $schedule->due_date) {
                                            $overdue = 1;
                                            $total_overdue = $total_overdue + 1;
                                            $overdue_date = '';
                                        }
                                        break;
                                    }
                                }
                            } else {
                                $paid = $payments;
                                $payments = 0;
                                if (date("Y-m-d") > $schedule->due_date) {
                                    $overdue = 1;
                                    $total_overdue = $total_overdue + 1;
                                    $overdue_date = $schedule->due_date;
                                }
                                $next_payment[$schedule->due_date] = (($schedule->principal + $schedule->interest + $schedule->fees + $schedule->penalty- $schedule->interest_waived) - $paid);
                            }
                        } else {
                            if (date("Y-m-d") > $schedule->due_date) {
                                $overdue = 1;
                                $total_overdue = $total_overdue + 1;
                                $overdue_date = $schedule->due_date;
                            }
                            $next_payment[$schedule->due_date] = (($schedule->principal + $schedule->interest + $schedule->fees + $schedule->penalty- $schedule->interest_waived));
                        }
                        $outstanding = $due - $paid;

                        ?>
                      <tr class="<?php if($overdue==1): ?> danger  <?php endif; ?> <?php if($overdue==0 && $outstanding==0): ?> success  <?php endif; ?>">
                        <td>
                          <?php echo e($count); ?>

                        </td>
                        <td>
                          <?php
                            //Fechas de pago esperada del prestamo            
                            $fechas_de_pagos = $schedule->due_date;
                            $timestamp = strtotime($fechas_de_pagos);
                            $fechas_de_pagos_final = date("d-m-Y", $timestamp);
                        ?>
                          <?php echo e($fechas_de_pagos_final); ?> </td>

                        <td style="">
                          <?php if(empty($paid_by) && $overdue==1): ?>
                          En atraso
                          <?php endif; ?>
                          <?php if(!empty($paid_by) && $overdue==1): ?>
                          <?php
                            //Fecha pago tardio recibido            
                            $pago_tardio_in = $paid_by;
                            $timestamp = strtotime($pago_tardio_in);
                            $pago_tardio_out = date("d-m-Y", $timestamp);
                            ?>
                          <?php echo e($pago_tardio_out); ?>


                          <?php endif; ?>
                          <?php if(!empty($paid_by) && $overdue==0): ?>
                          <?php
                            //Fecha pago tardio recibido            
                            $pago_atiempo_in = $paid_by;
                            $timestamp = strtotime($pago_atiempo_in);
                            $pago_atiempo_out = date("d-m-Y", $timestamp);
                            ?>
                          <?php echo e($pago_atiempo_out); ?>


                          <?php endif; ?>

                        </td>

                        <td>
                          <?php echo e($schedule->description); ?>

                        </td>
                        <td style="text-align:right">
                          <?php echo e(number_format($principal,2)); ?>

                        </td>
                        <td style="text-align:right">
                          <?php if($schedule->interest_waived>0): ?>
                          <s> <?php echo e(number_format($schedule->interest_waived,2)); ?></s>
                          <?php endif; ?>
                          <?php echo e(number_format($interest,2)); ?>

                        </td>
                        <td style="text-align:right">
                          <?php echo e(number_format($schedule->fees,2)); ?>

                        </td>
                        <td style="text-align:right">
                          <!--- REVISAR MORA --->
                          <?php echo e(number_format($schedule->penalty,2)); ?>

                        </td>
                        <td style="text-align:right; font-weight:bold">
                          <?php echo e(number_format($due,2)); ?>

                        </td>

                        <td style="text-align:right;">
                          <?php echo e(number_format($paid,2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format($outstanding,2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format($principal_balance,2)); ?>

                        </td>

                      </tr>
                      <?php
                        $count++;
                        }
                        ?>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td style="font-weight:bold"><?php echo e(trans_choice('general.total',1)); ?>

                          <?php echo e(trans_choice('general.due',1)); ?></td>
                        <td style="text-align:right;">
                          <?php echo e(number_format($totalPrincipal,2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format($totalInterest,2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format(\App\Helpers\GeneralHelper::loan_total_fees($loan->id)+$disbursement_charges,2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format(\App\Helpers\GeneralHelper::loan_total_penalty($loan->id),2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format($total_due+$disbursement_charges,2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format($total_paid+$disbursement_charges,2)); ?>

                        </td>
                        <td style="text-align:right;">
                          <?php echo e(number_format(\App\Helpers\GeneralHelper::loan_total_balance($loan->id),2)); ?>

                        </td>
                        <td></td>
                      </tr>
                    </tbody>
                  </table>

                </div>
              </div>
            </div>

            <div class="tab-pane" id="pending_dues">
              <div class="tab_content">
                <?php
                    $loan_due_items = \App\Helpers\GeneralHelper::loan_due_items($loan->id,
                        $loan->release_date, date("Y-m-d"));
                    $loan_paid_items = \App\Helpers\GeneralHelper::loan_paid_items($loan->id,
                        $loan->release_date, date("Y-m-d"));
                ?>
                <div class="row">
                  <div class="col-md-6">
                    <div class="row">
                      <div class="col-md-6">
                        <h6>
                          <b>% Pagado
                            :</b>
                        </h6>
                      </div>
                      <div class="col-md-6">
                        <?php
                            $count = \App\Models\LoanSchedule::where('due_date', '<=',
                                date("Y-m-d"))->where('loan_id', $loan->id)->count();
                        ?>
                        <?php if($count>0): ?>
                        <h6><b><?php echo e(round(($count-$total_overdue)/$count)); ?>%</b></h6>
                        <?php else: ?>
                        <h6><b>0 %</b></h6>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h6>
                          <b>Monto total en atraso:</b>
                        </h6>
                      </div>
                      <div class="col-md-6">
                        <?php if(($loan_due_items["principal"]+$loan_due_items["interest"]+$loan_due_items["fees"]+$loan_due_items["penalty"])>($loan_paid_items["principal"]+$loan_paid_items["interest"]+$loan_paid_items["fees"]+$loan_paid_items["penalty"])): ?>
                        <h6><b>
                            <span
                              class="text-danger"><?php echo e(number_format(($loan_due_items["principal"]+$loan_due_items["interest"]+$loan_due_items["fees"]+$loan_due_items["penalty"])-($loan_paid_items["principal"]+$loan_paid_items["interest"]+$loan_paid_items["fees"]+$loan_paid_items["penalty"]),2)); ?></span></b>
                        </h6>
                        <?php else: ?>
                        <h6><b> <span class="text-danger">0.00</span></b></h6>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h6>
                          <b>Dias en atraso:</b>
                        </h6>
                      </div>
                      <div class="col-md-6">
                        <?php if(!empty($overdue_date)): ?>
                        <?php
                            $date1 = new DateTime($overdue_date);
                            $date2 = new DateTime(date("Y-m-d"));
                            $days_arrears_count = $date2->diff($date1)->format("%a");
                        ?>
                        <h6>
                          <b><span class="text-danger"><?php echo e($days_arrears_count); ?></span></b>
                        </h6>
                        <?php else: ?>
                        <h6><b> <span class="text-success">Al dia</span></b></h6>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="row">
                      <div class="col-md-6">
                        <h6>
                          <b>Ultimo pago:</b>
                        </h6>
                      </div>
                      <div class="col-md-6">
                        <?php
                            $last_payment = \App\Models\LoanTransaction::where('loan_id', $loan->id)->where('transaction_type',
                                                        'repayment')->where('reversed', 0)->orderBy('date',
                                                        'desc')->first();
                            ?>
                        <?php if(!empty($last_payment)): ?>
                        <h6><b><?php echo e(number_format($last_payment->credit,2)); ?>

                            <?php                                    
                                $fecha_de_ultpago_in = $last_payment->date;
                                $fecha_de_ultpago_process = strtotime($fecha_de_ultpago_in);
                                $fecha_de_ultpago_out = date("d-m-Y", $fecha_de_ultpago_process);
                            ?>
                            en fecha <?php echo e($fecha_de_ultpago_out); ?></b></h6>
                        <?php else: ?>
                        No se han realizado pagos
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h6>
                          <b>Proximo pago:</b>
                        </h6>
                      </div>
                      <div class="col-md-6">
                        <?php
                            $count = \App\Models\LoanSchedule::where('due_date', '<=',
                                date("Y-m-d"))->where('loan_id', $loan->id)->count();
                            $first = 0;
                        ?>
                        <?php $__currentLoopData = $next_payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if ($key > date("Y-m-d")) {
                                if ($first == 0) {
                                    $fecha_de_proxpago_in = $key;
                                    $fecha_de_proxpago_process = strtotime($fecha_de_proxpago_in);
                                    $fecha_de_proxpago_out = date("d-m-Y", $fecha_de_proxpago_process);
                            
                                
                                    echo ' <h6><b>' . number_format($value,2) . ' en fecha ' . $fecha_de_proxpago_out . '</b></h6>';
                                }
                                
                                $first = $first + 1;
                            }
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h6>
                          <b>Fecha de vencimiento:</b>
                        </h6>
                      </div>
                      <div class="col-md-6">
                        <?php
                            $fecha_de_vencimiento_in = \App\Models\LoanSchedule::where('loan_id', $loan->id)->orderBy('due_date','asc')->get()->last()->due_date;
                            $fecha_de_vencimiento_process = strtotime($fecha_de_vencimiento_in);
                            $fecha_de_vencimiento_out = date("d-m-Y", $fecha_de_vencimiento_process);
                        ?>
                        <h6>
                          <b><?php echo e($fecha_de_vencimiento_out); ?></b>
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>


                <table id="order-listing" class="table">
                  <tbody>
                    <tr>
                      <th width="200">
                        <b>Balances</b>
                      </th>
                      <th style="text-align:right;">
                        <b>Capital</b>
                      </th>
                      <th style="text-align:right;">
                        <b>Interes</b>
                      </th>
                      <th style="text-align:right;">
                        <b>Cargos</b>
                      </th>
                      <th style="text-align:right;">
                        <b>Mora</b>
                      </th>
                      <th style="text-align:right;">
                        <b>Total</b>
                      </th>
                    </tr>
                    <?php
                    $loan_total_nopaid_principal = \App\Helpers\GeneralHelper::loan_total_principal($loan->id);
                    $loan_total_nopaid_interest = \App\Helpers\GeneralHelper::loan_total_interest($loan->id);
                    $loan_total_nopaid_fee = \App\Helpers\GeneralHelper::loan_total_fees($loan->id);
                    $loan_total_nopaid_penalty = \App\Helpers\GeneralHelper::loan_total_penalty($loan->id);
                    $loan_total_nopaid_total = $loan_total_nopaid_principal + $loan_total_nopaid_interest + $loan_total_nopaid_fee + $loan_total_nopaid_penalty;
                    ?>
                    <tr>
                      <td class="text-bold bg-danger">Balance Total
                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_nopaid_principal,2)); ?>

                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_nopaid_interest,2)); ?>

                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_nopaid_fee,2)); ?>

                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_nopaid_penalty,2)); ?>

                      </td>
                      <td style="text-align:right; font-weight:bold">
                        <?php echo e(number_format($loan_total_nopaid_total,2)); ?>

                      </td>
                    </tr>
                    <?php
                        $loan_total_paid_principal = \App\Models\JournalEntry::where('loan_id', $loan->id)->where('name', "Principal Repayment")->where('debit','=',NULL)->sum('credit');
                            $loan_total_paid_interest = \App\Models\JournalEntry::where('loan_id', $loan->id)->where('name', "Principal Repayment")->where('debit','=',NULL)->sum('credit');
                                $loan_total_paid_charge = \App\Models\JournalEntry::where('loan_id', $loan->id)->where('name', "Principal Repayment")->where('debit','=',NULL)->sum('credit');
                            $loan_total_paid_penalty = \App\Models\JournalEntry::where('loan_id', $loan->id)->where('name', "Principal Repayment")->where('debit','=',NULL)->sum('credit');
                        $total_paid_balance1 = $loan_total_paid_principal + $loan_total_paid_interest + $loan_total_paid_charge + $loan_total_paid_penalty;
                            
                        $id_total_pending_principal = \App\Helpers\GeneralHelper::loan_total_principal($loan->id);
                        $id_total_pending_interest = \App\Helpers\GeneralHelper::loan_total_interest($loan->id);
                        $id_total_pending_charge = \App\Helpers\GeneralHelper::loan_total_fees($loan->id);
                        $id_total_pending_penalty = \App\Helpers\GeneralHelper::loan_total_penalty($loan->id);
                        
                        $loan_total_pending_principal = $loan_total_nopaid_principal - $loan_total_paid_principal;
                        $loan_total_pending_interest = $loan_total_nopaid_interest - $loan_total_paid_interest;
                        $loan_total_pending_charge = $loan_total_nopaid_fee - $loan_total_paid_charge;
                        $loan_total_pending_penalty = $loan_total_nopaid_penalty - $loan_total_paid_penalty;
                        $loan_total_pending_total = $loan_total_pending_principal + $loan_total_pending_interest + $loan_total_pending_charge + $loan_total_pending_penalty;
                    ?>
                    <tr>
                      <td class="text-bold bg-green">
                        Balance Pagado
                      </td>
                      <td style="text-align:right">

                        <?php echo e(number_format($loan_total_paid_principal,2)); ?>

                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_paid_interest,2)); ?>

                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_paid_charge,2)); ?>

                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_paid_penalty,2)); ?>

                      </td>
                      <td style="text-align:right; font-weight:bold">
                        <?php echo e(number_format($total_paid_balance1,2)); ?>

                      </td>
                    </tr>

                    <tr>
                      <td class="text-bold btn-info">
                        Balance Pendiente
                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_pending_principal,2)); ?>

                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_pending_interest,2)); ?>


                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_pending_charge,2)); ?>


                      </td>
                      <td style="text-align:right">
                        <?php echo e(number_format($loan_total_pending_penalty,2)); ?>


                      </td>
                      <td style="text-align:right; font-weight:bold">
                        <?php echo e(number_format($loan_total_pending_total,2)); ?>


                      </td>
                    </tr>

                  </tbody>
                </table>
              </div>
            </div>

            <div class="modal fade" id="waiveInterest">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title"><?php echo e(trans_choice('general.waive',1)); ?> <?php echo e(trans_choice('general.interest',1)); ?>

                    </h4>
                  </div>
                  <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/waive_interest'),'method'=>'post')); ?>

                  <div class="modal-body">
                    <div class="form-group">
                      <div class="form-line">
                        <?php echo Form::label('date',trans_choice('general.date',1),array('class'=>' control-label')); ?>

                        <?php echo Form::text('date',date("Y-m-d"),array('class'=>'form-control
                        date-picker','required'=>'required')); ?>

                      </div>
                    </div>
                    <div class="form-group">
                      <div class="form-line">
                        <?php echo Form::label('amount',trans_choice('general.amount',1),array('class'=>' control-label')); ?>

                        <?php echo Form::text('amount',\App\Helpers\GeneralHelper::loan_total_interest($loan->id)-$loan_paid_items['interest'],array('class'=>'form-control
                        touchspin',''=>'','required'=>'required')); ?>

                      </div>
                    </div>
                    <div class="form-group">
                      <div class="form-line">
                        <?php echo Form::label( 'notes',trans_choice('general.note',2),array('class'=>' control-label')); ?>

                        <?php echo Form::textarea('notes',null,array('class'=>'form-control','rows'=>'3')); ?>

                      </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-info">Procesar</button>
                    <button type="button" class="btn default" data-dismiss="modal">Cancelar</button>
                  </div>
                  <?php echo Form::close(); ?>

                </div>
                <!-- /.modal-content -->
              </div>
              <!-- /.modal-dialog -->
            </div>

            <div class="modal fade" id="addCharge">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">*</span></button>
                    <h4 class="modal-title">Agregar ajuste de saldo</h4>
                  </div>
                  <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/add_charge'),'method'=>'post')); ?>

                  <div class="modal-body">
                    <?php
                        $specified_charges = [];
                        foreach (\App\Models\Charge::where('charge_type',
                            'specified_due_date')->where('active',
                            1)->get() as $key) {
                            $specified_charges[$key->id] = $key->name;
                        }
                    ?>
                    <div style="display: none;" class="form-group">
                      <?php echo Form::label('charge',trans_choice('general.charge',1),array('class'=>' ')); ?>

                      <?php echo Form::select('charge',$specified_charges,null,array('class'=>' select2')); ?>

                    </div>
                    <div class="form-group">
                      <?php echo Form::label('date',trans_choice('general.date',1),array('class'=>' control-label')); ?>

                      <?php echo Form::text('date',date("Y-m-d"),array('class'=>'form-control
                      date-picker','required'=>'required')); ?>

                    </div>
                    <div class="form-group">
                      <?php echo Form::label('amount',trans_choice('general.amount',1),array('class'=>' control-label')); ?>

                      <?php echo Form::text('amount',null,array('class'=>'form-control
                      touchspin',''=>'','required'=>'required')); ?>

                    </div>
                    <div class="form-group">
                      <?php echo Form::label( 'notes',trans_choice("Motivo del ajuste",2),array('class'=>' control-label')); ?>

                      <!--<?php echo Form::textarea('notes',null,array('class'=>'form-control','rows'=>'3')); ?>-->
                      <?php echo Form::select('notes',array('Ajuste de Interes (+)'=>trans_choice("Ajuste de Interes
                      (+)",1),'Ajuste de Mora (+)'=>trans_choice("Ajuste de Mora (+)",1)),null,array('class'=>'
                      select2','required'=>'required')); ?>

                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
                    <button type="button" class="btn default"
                      data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
                  </div>
                  <?php echo Form::close(); ?>

                </div>
                <!-- /.modal-content -->
              </div>
              <!-- /.modal-dialog -->
            </div>
            <?php endif; ?>

            <div class="tab-pane active" id="loan_terms">
              <div class="row">
                <div class="col-sm-8">
                  <?php if($loan->status=='pending'): ?>
                  <div class="col-sm-6">
                    <?php if(Sentinel::hasAccess('loans.approve')): ?>
                    <button type="button" class="btn btn-success m-10" data-toggle="modal"
                      data-target="#approveLoan"><?php echo e(trans_choice('general.approve',1)); ?></button>
                    <button type="button" class="btn btn-danger m-10" data-toggle="modal"
                      data-target="#declineLoan"><?php echo e(trans_choice('general.decline',1)); ?></button>
                    <?php endif; ?>
                  </div>
                  <?php endif; ?>
                  <?php if($loan->status=='declined'): ?>
                  <div class="col-sm-6">
                    <?php if(Sentinel::hasAccess('loans.approve')): ?>
                    <button type="button" class="btn btn-success m-10" data-toggle="modal"
                      data-target="#approveLoan"><?php echo e(trans_choice('general.approve',1)); ?></button>
                    <?php endif; ?>
                  </div>
                  <?php endif; ?>
                  <?php if($loan->status=='approved'): ?>
                  <div class="col-sm-6">
                    <?php if(Sentinel::hasAccess('loans.disburse')): ?>
                    <button type="button" class="btn btn-success m-10" data-toggle="modal"
                      data-target="#disburseLoan"><?php echo e(trans_choice('general.disburse',1)); ?></button>
                    <a type="button" class="btn btn-danger  delete m-10"
                      href="<?php echo e(url('loan/'.$loan->id.'/unapprove')); ?>"><?php echo e(trans_choice('general.undo',1)); ?>

                      <?php echo e(trans_choice('general.approval',1)); ?></a>
                    <?php endif; ?>
                  </div>
                  <?php endif; ?>
                  <?php if($loan->status=='written_off'): ?>
                  <div class="col-sm-6">
                    <?php if(Sentinel::hasAccess('loans.writeoff')): ?>
                    <a type="button" class="btn btn-danger  delete m-10"
                      href="<?php echo e(url('loan/'.$loan->id.'/unwrite_off')); ?>"><?php echo e(trans_choice('general.undo',1)); ?>

                      <?php echo e(trans_choice('general.write_off',1)); ?></a>
                    <?php endif; ?>
                  </div>
                  <?php endif; ?>
                  <?php if($loan->status=='withdrawn'): ?>
                  <div class="col-sm-6">
                    <?php if(Sentinel::hasAccess('loans.withdraw')): ?>
                    <a type="button" class="btn btn-danger  delete m-10"
                      href="<?php echo e(url('loan/'.$loan->id.'/unwithdraw')); ?>"><?php echo e(trans_choice('general.undo',1)); ?>

                      <?php echo e(trans_choice('general.withdrawal',1)); ?></a>
                    <?php endif; ?>
                  </div>
                  <?php endif; ?>
                  <?php if($loan->status=='disbursed'): ?>
                  <div class="col-sm-3">
                    <div class="btn-group-horizontal">
                      <?php if(Sentinel::hasAccess('loans.disburse')): ?>
                      <a type="button" class="btn btn-danger delete m-10"
                        href="<?php echo e(url('loan/'.$loan->id.'/undisburse')); ?>"><?php echo e(trans_choice('general.undo',1)); ?>

                        <?php echo e(trans_choice('general.disbursement',1)); ?></a>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="input-group-btn">
                      <button type="button" class="btn btn-info dropdown-toggle m-10" data-toggle="dropdown"
                        aria-expanded="false">Mas opciones
                        <span class="fa fa-caret-down"></span></button>
                      <ul class="dropdown-menu" role="menu">
                        <?php if(Sentinel::hasAccess('loans.writeoff')): ?>
                        <li>
                          <a href="#" class="" data-toggle="modal" data-target="#writeoffLoan">Llevar a perdida</a>
                        </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.update')): ?>
                        <li>
                          <a href="#" class="" data-toggle="modal" data-target="#waiveInterest">- Reducir saldo</a>
                        </li>
                        <?php endif; ?>
                        <?php if(Sentinel::hasAccess('loans.update')): ?>
                        <li>
                          <a href="#" class="" data-toggle="modal" data-target="#addCharge">+ Agregar saldo</a>
                        </li>
                        <?php endif; ?>
                      </ul>
                    </div>
                  </div>
                  <?php endif; ?>

                  <?php if($loan->status=="disbursed" || $loan->status=="closed" || $loan->status=="withdrawn" ||
                  $loan->status=="written_off" || $loan->status=="rescheduled" ): ?>
                  <div class="col-sm-3">
                    <div class="input-group-btn">
                      <button type="button" class="btn btn-info dropdown-toggle m-10" data-toggle="dropdown"
                        aria-expanded="false">Generar Calendario
                        <span class="fa fa-caret-down"></span></button>
                      <ul class="dropdown-menu" role="menu">

                        <li>
                          <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/print')); ?>" target="_blank">Imprimir</a>
                        </li>

                        <li>
                          <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/pdf')); ?>" target="_blank">Descargar en
                            PDF</a>
                        </li>
                        <?php if(Sentinel::hasAccess('communication.create')): ?>
                        <li>
                          <a href="<?php echo e(url('loan/'.$loan->id.'/loan_statement/email')); ?>">Enviar por Email</a>
                        </li>
                        <?php endif; ?>
                      </ul>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>

                <div class="col-sm-4 pull-right">
                  <div class="btn-group-horizontal">
                    <?php if(Sentinel::hasAccess('loans.update')): ?>
                    <a type="button" class="btn btn-info m-10"
                      href="<?php echo e(url('loan/'.$loan->id.'/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?>

                      <?php echo e(trans_choice('general.loan',1)); ?></a>
                    <?php endif; ?>

                    <?php if(Sentinel::hasAccess('loans.delete')): ?>
                    <a type="button" class="btn btn-info m-10 deleteLoan"
                      href="<?php echo e(url('loan/'.$loan->id.'/delete')); ?>"><?php echo e(trans_choice('general.delete',1)); ?>

                      <?php echo e(trans_choice('general.loan',1)); ?></a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>

              <div class="panel-body no-padding">
                <table class="table table-condensed">
                  <tbody>
                    <tr>
                      <td>
                        <b>Estatus del Prestamo</b>
                      </td>
                      <td>
                        <?php if($loan->maturity_date < date("Y-m-d") && \App\Helpers\GeneralHelper::loan_total_balance($loan->
                          id)>0): ?>
                          <span class="label label-danger"><?php echo e(trans_choice('general.past_maturity',1)); ?></span>
                          <?php else: ?>
                          <?php if($loan->status=='pending'): ?>
                          <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?>

                            <?php echo e(trans_choice('general.approval',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='approved'): ?>
                          <span class="label label-info"><?php echo e(trans_choice('general.awaiting',1)); ?>

                            <?php echo e(trans_choice('general.disbursement',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='disbursed'): ?>
                          <span class="label label-info"><?php echo e(trans_choice('general.active',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='declined'): ?>
                          <span class="label label-danger"><?php echo e(trans_choice('general.declined',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='withdrawn'): ?>
                          <span class="label label-danger"><?php echo e(trans_choice('general.withdrawn',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='written_off'): ?>
                          <span class="label label-danger"><?php echo e(trans_choice('general.written_off',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='closed'): ?>
                          <span class="label label-success"><?php echo e(trans_choice('general.closed',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='pending_reschedule'): ?>
                          <span class="label label-warning"><?php echo e(trans_choice('general.pending',1)); ?>

                            <?php echo e(trans_choice('general.reschedule',1)); ?></span>
                          <?php endif; ?>
                          <?php if($loan->status=='rescheduled'): ?>
                          <span class="label label-info"><?php echo e(trans_choice('general.rescheduled',1)); ?></span>
                          <?php endif; ?>
                          <?php endif; ?>
                      </td>
                    </tr>
                    <tr>
                      <td width="200">
                        <b>Prestamo Numero</b>
                      </td>
                      <td>000<?php echo e($loan->id); ?></td>
                    </tr>
                    <tr>
                      <td>
                        <b>Ruta</b>
                      </td>
                      <td>
                        <?php if(!empty($loan->loan_product)): ?>
                        <?php echo e($loan->loan_product->name); ?>

                        <?php endif; ?>
                      </td>
                    </tr>

                    <tr>
                      <td><b>Desembolsado por</b></td>
                      <td>
                        <?php if(!empty($loan->loan_disbursed_by)): ?>
                        <?php echo e($loan->loan_disbursed_by->name); ?>

                        <?php endif; ?>
                      </td>
                    </tr>

                    <tr>

                      <td>
                        <b>Monto Aprobado</b>
                      </td>
                      <td><?php echo e(number_format($loan->principal,2)); ?></td>

                    </tr>

                    <tr>

                      <td>
                        <b>Fecha de Desembolso</b>
                      </td>
                      <?php
                        $original_date = $loan->release_date;
                        $timestamp = strtotime($original_date);
                        $fecha_de_desembolso = date("d-m-Y", $timestamp);
                        ?>
                      <td>
                        <?php echo e($fecha_de_desembolso); ?>

                      </td>

                    </tr>

                    <tr>
                      <td>
                        <b>Fecha del primer Pago</b>
                      </td>
                      <?php
                        $original_date_first = $loan->first_payment_date;
                        $timestamp_first = strtotime($original_date_first);
                        $fecha_de_primerpago = date("d-m-Y", $timestamp_first);
                    ?>
                      <td><?php echo e($fecha_de_primerpago); ?></td>
                    </tr>

                    <tr>
                      <td>
                        <b>Tipo de interes</b>
                      </td>
                      <td>
                        <?php if($loan->interest_method=='declining_balance_equal_installments'): ?>
                        Interes Amortizable (Base Balance General)
                        <?php endif; ?>
                        <?php if($loan->interest_method=='declining_balance_equal_principal'): ?>
                        Interes Amortizable (Base Capital)
                        <?php endif; ?>
                        <?php if($loan->interest_method=='interest_only'): ?>
                        Interes unico
                        <?php endif; ?>
                        <?php if($loan->interest_method=='flat_rate'): ?>
                        Interes fijo
                        <?php endif; ?>
                        <?php if($loan->interest_method=='compound_interest'): ?>
                        <?php echo e(trans_choice('general.compound_interest',1)); ?>

                        <?php endif; ?>
                      </td>
                    </tr>

                    <tr>
                      <td>
                        <b>Interes aplicado</b>
                      </td>
                      <td><?php echo e(number_format($loan->interest_rate,2)); ?>% / <?php echo e($loan->interest_period); ?>

                      </td>
                    </tr>                    
                    
                    <tr>
                      <td>
                        <b>Mora activada</b>
                      </td>
                      <td><input type="checkbox" name="penalty_status_active" id="penalty_status_active" <?php if($loan->penalty_status == 1): ?> checked <?php endif; ?> value="1" class="form-control" style="width: 20px;" onchange="update_penalty_status(this)">
                      </td>
                    </tr>

                    <tr>
                      <td>
                        <b>Duracion</b>
                      </td>
                      <td><?php echo e(number_format($loan->loan_duration,2)); ?>


                        <?php if($loan->loan_duration_type=='month'): ?>
                        Mes
                        <?php endif; ?>
                        <?php if($loan->loan_duration_type=='day'): ?>
                        Dia
                        <?php endif; ?>
                        <?php if($loan->loan_duration_type=='week'): ?>
                        Semana
                        <?php endif; ?>
                        <?php if($loan->loan_duration_type=='year'): ?>
                        Año
                        <?php endif; ?>
                      </td>
                    </tr>
                    
                    <tr>
                      <td><b>Frecuencia de pago</b></td>
                      <td>
                        <?php if($loan->repayment_cycle=='daily'): ?>
                        <?php echo e(trans_choice('general.daily',1)); ?>

                        <?php endif; ?>
                        <?php if($loan->repayment_cycle=='weekly'): ?>
                        <?php echo e(trans_choice('general.weekly',1)); ?>

                        <?php endif; ?>
                        <?php if($loan->repayment_cycle=='monthly'): ?>
                        <?php echo e(trans_choice('general.monthly',1)); ?>

                        <?php endif; ?>
                        <?php if($loan->repayment_cycle=='bi_monthly'): ?>
                        <?php echo e(trans_choice('general.bi_monthly',1)); ?>

                        <?php endif; ?>
                        <?php if($loan->repayment_cycle=='quarterly'): ?>
                        <?php echo e(trans_choice('general.quarterly',1)); ?>

                        <?php endif; ?>
                        <?php if($loan->repayment_cycle=='semi_annual'): ?>
                        <?php echo e(trans_choice('general.semi_annually',1)); ?>

                        <?php endif; ?>
                        <?php if($loan->repayment_cycle=='annually'): ?>
                        <?php echo e(trans_choice('general.annual',1)); ?>

                        <?php endif; ?>
                      </td>
                    </tr>

                    <tr>
                      <td><b>Cantidad de pagos</b></td>
                      <td>
                        <?php echo e(\App\Models\LoanSchedule::where('loan_id',$loan->id)->count()); ?>

                      </td>
                    </tr>

                    <tr>
                      <td></td>
                    </tr>

                  </tbody>
                </table>
              </div>

            </div>

            <div class="tab-pane" id="loan_collateral">
              <div class="btn-group-horizontal">
                <?php if(Sentinel::hasAccess('collateral.create')): ?>
                <a type="button" class="btn btn-info m-10"
                  href="<?php echo e(url('collateral/'.$loan->id.'/create?return_url='.Request::url())); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                  <?php echo e(trans_choice('general.collateral',1)); ?></a>
                <?php endif; ?>
              </div>
              <div class="box box-success">
                <div class="table-responsive">
                  <table id="data-table" class="table table-striped table-condensed table-hover">
                    <thead>
                      <tr>
                        <th><?php echo e(trans_choice('general.type',1)); ?></th>
                        <th><?php echo e(trans_choice('general.name',1)); ?></th>
                        <th><?php echo e(trans_choice('general.value',1)); ?></th>
                        <th><?php echo e(trans_choice('general.status',1)); ?></th>
                        <th><?php echo e(trans_choice('general.date',1)); ?></th>
                        <th><?php echo e(trans_choice('general.action',1)); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $loan->collateral; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>
                          <?php if(!empty($key->collateral_type)): ?>
                          <?php echo e($key->collateral_type->name); ?>

                          <?php endif; ?>
                        </td>
                        <td><?php echo e($key->name); ?></td>
                        <td><?php echo e($key->value); ?></td>
                        <td>
                          <?php if($key->status=='deposited_into_branch'): ?>
                          <?php echo e(trans_choice('general.deposited_into_branch',1)); ?>

                          <?php endif; ?>
                          <?php if($key->status=='collateral_with_borrower'): ?>
                          <?php echo e(trans_choice('general.collateral_with_borrower',1)); ?>

                          <?php endif; ?>
                          <?php if($key->status=='returned_to_borrower'): ?>
                          <?php echo e(trans_choice('general.returned_to_borrower',1)); ?>

                          <?php endif; ?>
                          <?php if($key->status=='repossession_initiated'): ?>
                          <?php echo e(trans_choice('general.repossession_initiated',1)); ?>

                          <?php endif; ?>
                          <?php if($key->status=='repossessed'): ?>
                          <?php echo e(trans_choice('general.repossessed',1)); ?>

                          <?php endif; ?>
                          <?php if($key->status=='sold'): ?>
                          <?php echo e(trans_choice('general.sold',1)); ?>

                          <?php endif; ?>
                          <?php if($key->status=='lost'): ?>
                          <?php echo e(trans_choice('general.lost',1)); ?>

                          <?php endif; ?>
                        </td>
                        <td><?php echo e($key->date); ?></td>
                        <td>
                          <div class="btn-group">
                            <button type="button" class="btn btn-info btn-xs dropdown-toggle" data-toggle="dropdown"
                              aria-expanded="false">
                              <?php echo e(trans('general.choose')); ?> <span class="caret"></span>
                              <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                              <?php if(Sentinel::hasAccess('collateral.view')): ?>
                              <li><a href="<?php echo e(url('collateral/'.$key->id.'/show')); ?>"><i class="fa fa-search"></i>
                                  <?php echo e(trans('general.view')); ?>

                                </a></li>
                              <?php endif; ?>
                              <?php if(Sentinel::hasAccess('collateral.update')): ?>
                              <li><a href="<?php echo e(url('collateral/'.$key->id.'/edit')); ?>"><i class="fa fa-edit"></i>
                                  <?php echo e(trans('general.edit')); ?>

                                </a></li>
                              <?php endif; ?>
                              <?php if(Sentinel::hasAccess('collateral.delete')): ?>
                              <li>
                                <a href="<?php echo e(url('collateral/'.$key->id.'/delete')); ?>" class="delete"><i
                                    class="fa fa-trash"></i> <?php echo e(trans('general.delete')); ?>

                                </a>
                              </li>
                              <?php endif; ?>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div class="tab-pane" id="loan_guarantors">
              <div class="btn-group-horizontal">
                <?php if(Sentinel::hasAccess('loans.guarantor.create')): ?>
                <a type="button" class="btn btn-info m-10" data-toggle="modal"
                  data-target="#addGuarantor"><?php echo e(trans_choice('general.add',1)); ?>

                  <?php echo e(trans_choice('general.guarantor',1)); ?></a>
                <?php endif; ?>
              </div>
              <div class="box box-success">
                <div class="table-responsive">
                  <table id="data-table" class="table table-bordered table-condensed table-hover">
                    <thead>
                      <tr>
                        <th><?php echo e(trans_choice('general.full_name',1)); ?></th>
                        <th><?php echo e(trans_choice('general.business',1)); ?></th>
                        <th><?php echo e(trans_choice('general.unique',1)); ?>#</th>
                        <th><?php echo e(trans_choice('general.mobile',1)); ?></th>
                        <th><?php echo e(trans_choice('general.email',1)); ?></th>
                        <th><?php echo e(trans_choice('general.action',1)); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $loan->guarantors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(!empty($key->guarantor)): ?>
                      <tr>
                        <td><?php echo e($key->guarantor->first_name); ?> <?php echo e($key->guarantor->last_name); ?></td>
                        <td><?php echo e($key->guarantor->business_name); ?></td>
                        <td><?php echo e($key->guarantor->unique_number); ?></td>
                        <td><?php echo e($key->guarantor->mobile); ?></td>
                        <td><?php echo e($key->guarantor->email); ?></td>
                        <td>
                          <div class="btn-group">
                            <button type="button" class="btn btn-info btn-xs dropdown-toggle" data-toggle="dropdown"
                              aria-expanded="false">
                              <?php echo e(trans('general.choose')); ?> <span class="caret"></span>
                              <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-right" role="menu">

                              <?php if(Sentinel::hasAccess('loans.guarantor.create')): ?>
                              <li>
                                <a href="<?php echo e(url('guarantor/'.$key->guarantor->id.'/show')); ?>"><i
                                    class="fa fa-search"></i> <?php echo e(trans_choice('general.detail',2)); ?>

                                </a>
                              </li>
                              <?php endif; ?>
                              <?php if(Sentinel::hasAccess('loans.guarantor.delete')): ?>
                              <li>
                                <a href="<?php echo e(url('loan/guarantor/'.$key->guarantor->id.'/remove')); ?>" class="delete"><i
                                    class="fa fa-minus"></i> <?php echo e(trans('general.remove')); ?>

                                </a>
                              </li>
                              <?php endif; ?>
                              <?php if(Sentinel::hasAccess('loans.guarantor.update')): ?>
                              <li>
                                <a href="<?php echo e(url('guarantor/'.$key->guarantor->id.'/edit')); ?>"><i class="fa fa-edit"></i>
                                  <?php echo e(trans('general.edit')); ?>

                                </a>
                              </li>
                              <?php endif; ?>
                              <?php if(Sentinel::hasAccess('loans.guarantor.delete')): ?>
                              <li>
                                <a href="<?php echo e(url('guarantor/'.$key->guarantor->id.'/delete')); ?>" class="delete"><i
                                    class="fa fa-trash"></i> <?php echo e(trans('general.delete')); ?>

                                </a>
                              </li>
                              <?php endif; ?>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div class="tab-pane" id="loan_files">
              <p>Para agregar nuevos archivos de préstamos o eliminar archivos existentes, haga clic en el <b>Términos
                  del préstamo</b> pestaña y
                entonces
                <b>Editar préstamo</b>.
              </p>
              <ul class="" style="font-size:12px; padding-left:10px">

                <?php $__currentLoopData = unserialize($loan->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo asset('uploads/'.$value); ?>" target="_blank"><?php echo $value; ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            
            <div class="tab-pane" id="loan_comments">
              <div class="tab_content">
                <div class="btn-group-horizontal">
                  <a type="button" class="btn btn-info m-10"
                    href="<?php echo e(url('loan/'.$loan->id.'/loan_comment/create')); ?>"><?php echo e(trans_choice('general.add',1)); ?>

                    <?php echo e(trans_choice('general.comment',2)); ?></a>
                </div>


                <div class="panel-footer box-comments">

                  <?php $__currentLoopData = $loan->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="media">
                    <div class="media-left">
                      <a href="#"><img src="assets/images/placeholder.jpg" class="img-circle img-md" alt=""></a>
                    </div>

                    <div class="media-body">
                      <?php echo $comment->notes; ?>


                      <div class="media-annotation mt-5">
                        <i class="icon-user"></i>
                        <?php if(!empty(\App\Models\User::find($comment->user_id))): ?>
                        <?php echo e(\App\Models\User::find($comment->user_id)->first_name); ?>

                        <?php echo e(\App\Models\User::find($comment->user_id)->last_name); ?>

                        <?php endif; ?>
                        <i class="icon-alarm"></i> <?php echo e($comment->created_at); ?>

                        <div class="btn-group-horizontal pull-right">
                          <a type="button" class="btn bg-info btn-xs text-bold"
                            href="<?php echo e(url('loan/'.$loan->id.'/loan_comment/'.$comment->id.'/edit')); ?>"><?php echo e(trans_choice('general.edit',1)); ?></a><a
                            type="button" class="btn btn-danger btn-xs text-bold deleteComment"
                            href="<?php echo e(url('loan/'.$loan->id.'/loan_comment/'.$comment->id.'/delete')); ?>"><?php echo e(trans_choice('general.delete',1)); ?></a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
            <!-- /.tab-pane -->
          </div>
          <!-- /.tab-content -->
        </div>
      </div>
      <!-- nav-tabs-custom -->
    </div>
  </div>
  <div class="modal fade" id="approveLoan">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title">Aprobar prestamo</h4>
        </div>
        <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/approve'),'method'=>'post')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('Fecha aprobacion',null,array('class'=>' control-label')); ?>

              <?php echo Form::text('approved_date',date("Y-m-d"),array('class'=>'form-control
              date-picker','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('Monto aprobado',null,array('class'=>' control-label')); ?>

              <?php echo Form::text('approved_amount',$loan->principal,array('class'=>'form-control
              touchspin','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label( 'Comentarios',null,array('class'=>' control-label')); ?>

              <?php echo Form::textarea('approved_notes','',array('class'=>'form-control','rows'=>'3')); ?>

            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info">Procesar</button>
          <button type="button" class="btn default" data-dismiss="modal">Cancelar</button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="disburseLoan">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title">Desembolsar prestamo</h4>
        </div>
        <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/disburse'),'method'=>'post')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('Fecha desembolso',null,array('class'=>' control-label')); ?>

              <?php echo Form::text('disbursed_date',$loan->release_date,array('class'=>'form-control
              date-picker','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('Fecha primer pago',null,array('class'=>' control-label')); ?>

              <?php echo Form::text('first_payment_date',$loan->first_payment_date,array('class'=>'form-control
              date-picker',''=>'','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('Desembolsado por',null,array('class'=>' control-label')); ?>

              <?php echo Form::select('loan_disbursed_by_id',$loan_disbursed_by,null,array('class'=>'form-control','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label( 'Comentarios',null,array('class'=>' control-label')); ?>

              <?php echo Form::textarea('disbursed_notes','',array('class'=>'form-control','rows'=>'3')); ?>

            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info">Procesar</button>
          <button type="button" class="btn default" data-dismiss="modal">Cancelar</button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="declineLoan">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title">Declinar prestamo</h4>
        </div>
        <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/decline'),'method'=>'post')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('Fecha declinacion',null,array('class'=>' control-label')); ?>

              <?php echo Form::text('declined_date',date("Y-m-d"),array('class'=>'form-control
              date-picker','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label( 'Comentarios',null,array('class'=>' control-label')); ?>

              <?php echo Form::textarea('declined_notes','',array('class'=>'form-control','rows'=>'3','required'=>'required')); ?>

            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info">Procesar</button>
          <button type="button" class="btn default" data-dismiss="modal">Cancelar</button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="writeoffLoan">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title">LLevar a perdida</h4>
        </div>
        <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/write_off'),'method'=>'post')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('Fecha de castigo',trans_choice('general.date',1),array('class'=>' control-label')); ?>

              <?php echo Form::text('written_off_date',date("Y-m-d"),array('class'=>'form-control
              date-picker','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label( 'Comentarios',trans_choice('general.note',2),array('class'=>' control-label')); ?>

              <?php echo Form::textarea('written_off_notes','',array('class'=>'form-control','rows'=>'3','required'=>'required')); ?>

            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info">Procesar</button>
          <button type="button" class="btn default" data-dismiss="modal">Cancelar</button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="withdrawLoan">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title"><?php echo e(trans_choice('general.withdraw',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h4>
        </div>
        <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/withdraw'),'method'=>'post')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('withdrawn_date',trans_choice('general.date',1),array('class'=>' control-label')); ?>

              <?php echo Form::text('withdrawn_date',date("Y-m-d"),array('class'=>'form-control
              date-picker','required'=>'required')); ?>

            </div>
          </div>
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label( 'withdrawn_notes',trans_choice('general.note',2),array('class'=>' control-label')); ?>

              <?php echo Form::textarea('withdrawn_notes','',array('class'=>'form-control','rows'=>'3','required'=>'required')); ?>

            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
          <button type="button" class="btn default" data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="withdrawSaving">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title"><?php echo e(trans_choice('general.withdraw',1)); ?> <?php echo e(trans_choice('general.saving',1)); ?></h4>
        </div>
        <?php echo Form::open(array('url' =>'','method'=>'post','id'=>'withdrawSavingForm')); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo Form::label('amount',trans_choice('general.amount',1),array('class'=>'')); ?>

            <?php echo Form::text('amount',null, array('class' => 'form-control touchspin',
            'id'=>'accepted_amount','required'=>'')); ?>

          </div>
          <div class="form-group">
            <?php echo Form::label('date',trans_choice('general.date',2),array('class'=>'')); ?>

            <?php echo Form::text('date',date("Y-m-d"), array('class' => 'form-control date-picker',
            'placeholder'=>'','required'=>'')); ?>

          </div>
          <div class="form-group">
            <?php echo Form::label('time',trans_choice('general.time',2),array('class'=>'')); ?>

            <?php echo Form::text('time',date("H:i"), array('class' => 'form-control time-picker',
            'placeholder'=>'','required'=>'')); ?>

          </div>
          <div class="form-group">
            <?php echo Form::label('notes',trans_choice('general.note',2),array('class'=>'')); ?>

            <?php echo Form::textarea('notes',null, array('class' => 'form-control', 'placeholder'=>'',)); ?>

          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
          <button type="button" class="btn default" data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="rescheduleLoan">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title"><?php echo e(trans_choice('general.reschedule',1)); ?> <?php echo e(trans_choice('general.loan',1)); ?></h4>
        </div>
        <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/reschedule'),'method'=>'get')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('type',trans_choice('general.reschedule',1).'
              '.trans_choice('general.on',1),array('class'=>' control-label')); ?>

              <?php echo Form::select('type',['0'=>trans_choice('general.outstanding_p',1),'1'=>trans_choice('general.outstanding_p_i',1),'2'=>trans_choice('general.outstanding_p_i_f',1),'3'=>trans_choice('general.outstanding_total',1)],null,array('class'=>'form-control','required'=>'required')); ?>

            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
          <button type="button" class="btn default" data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="addGuarantor">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">*</span></button>
          <h4 class="modal-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.guarantor',1)); ?></h4>
        </div>
        <?php echo Form::open(array('url' => url('loan/'.$loan->id.'/guarantor/add'),'method'=>'post')); ?>

        <div class="modal-body">
          <div class="form-group">
            <div class="form-line">
              <?php echo Form::label('guarantor_id',trans_choice('general.guarantor',1),array('class'=>' control-label')); ?>

              <?php echo Form::select('guarantor_id',$guarantors,null,array('class'=>'
              select2','required'=>'required','placeholder'=>'')); ?>

            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-info"><?php echo e(trans_choice('general.save',1)); ?></button>
          <button type="button" class="btn default" data-dismiss="modal"><?php echo e(trans_choice('general.close',1)); ?></button>
        </div>
        <?php echo Form::close(); ?>

      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
<script>
$('#repayments-data-table').DataTable({
  dom: '<"datatable-header"fl><"datatable-scroll"t><"datatable-footer"ip>',
  autoWidth: false,
  columnDefs: [{
    orderable: false,
    width: '100px',
    targets: [8]
  }],
  "order": [
    [0, "asc"]
  ],
  language: {
    "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
    "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
    "info": "<?php echo e(trans('general.info')); ?>",
    "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
    "search": "<?php echo e(trans('general.search')); ?>:",
    "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
    "paginate": {
      "first": "<?php echo e(trans('general.first')); ?>",
      "last": "<?php echo e(trans('general.last')); ?>",
      "next": "<?php echo e(trans('general.next')); ?>",
      "previous": "<?php echo e(trans('general.previous')); ?>"
    }
  },
  drawCallback: function() {
    $('.delete').on('click', function(e) {
      e.preventDefault();
      var href = $(this).attr('href');
      swal({
        title: 'Estas seguro?',
        text: '',
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ok',
        cancelButtonText: 'Cancel'
      }).then(function() {
        window.location = href;
      })
    });
  }
});
</script>
<script>
$(document).ready(function() {
  $("body").addClass('sidebar-xs');
  $('#withdrawSaving').on('shown.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    var amount = $(e.relatedTarget).data('amount');
    var url = "<?php echo url('loan/'.$loan->id.'/guarantor'); ?>/" + id + "/withdraw";
    $(e.currentTarget).find("#withdrawSavingForm").attr('action', url);
    $(e.currentTarget).find("#accepted_amount").val(amount);
  });
  $('.deleteLoan').on('click', function(e) {
    e.preventDefault();
    var href = $(this).attr('href');
    swal({
      title: '<?php echo e(trans_choice('
      Estas seguro ? ',1)); ?>',
      text : '<?php echo e(trans_choice('
      general.delete_loan_msg ',1)); ?>',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: '<?php echo e(trans_choice('
      Si ',1)); ?>',
      cancelButtonText: '<?php echo e(trans_choice('
      No ',1)); ?>'
    }).then(function() {
      window.location = href;
    })
  });
  $('.deletePayment').on('click', function(e) {
    e.preventDefault();
    var href = $(this).attr('href');
    swal({
      title: '<?php echo e(trans_choice('
      Estas seguro ? ',1)); ?>',
      text : '<?php echo e(trans_choice('
      general.delete_payment_msg ',1)); ?>',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: '<?php echo e(trans_choice('
      Si ',1)); ?>',
      cancelButtonText: '<?php echo e(trans_choice('
      No ',1)); ?>'
    }).then(function() {
      window.location = href;
    })
  });
  $('.deleteComment').on('click', function(e) {
    e.preventDefault();
    var href = $(this).attr('href');
    swal({
      title: '<?php echo e(trans_choice('
      Estas seguro ? ',1)); ?>',
      text : '',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: '<?php echo e(trans_choice('
      Si ',1)); ?>',
      cancelButtonText: '<?php echo e(trans_choice('
      No ',1)); ?>'
    }).then(function() {
      window.location = href;
    })
  });
});

function update_penalty_status(obj) {
  var loan_id = <?php echo $loan->id ?>;
  console.log('id ==== ' + loan_id);
  var status = obj.checked;
  var sendVal = 1;
  if (status == true) {
    sendVal = 1;
  } else {
    sendVal = 0;
  }
  var post_url = "<?php echo e(url('loan/update_penalty_status')); ?>";
  var form_data = {
    id: loan_id,
    status: sendVal,
    _token: "<?php echo e(csrf_token()); ?>"
  };
  console.log(form_data);
  console.log(post_url);

  $.post(post_url, form_data, function(response) {
    console.log('=========  response data  ======= ' + response);
  });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>