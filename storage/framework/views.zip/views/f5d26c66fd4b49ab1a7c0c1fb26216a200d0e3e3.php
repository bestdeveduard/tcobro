<?php $__env->startSection('title'); ?>
Collectors
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">

    <?php if(Session::has('flash_notification.message')): ?>
    <script>
    toastr. {
      {
        Session::get('flash_notification.level')
      }
    }('<?php echo e(Session::get("flash_notification.message")); ?>', 'Response Status')
    </script>
    <?php endif; ?>
    <?php if(isset($msg)): ?>
    <div class="alert alert-success">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <?php echo e($msg); ?>

    </div>
    <?php endif; ?>
    <?php if(isset($error)): ?>
    <div class="alert alert-error">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <?php echo e($error); ?>

    </div>
    <?php endif; ?>
    <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>

    <h5>New User collector</h5>
    <?php echo Form::open(array('url' => url('user/collector/store'), 'method' => 'post', 'name' => 'form','class'=>'pt-3
    form-sample')); ?>

    <p class="card-description">
    <h5 style="color:#46b979;">Personal information</h5>
    <br>
    </p>
    <div class="row">
      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Name *</label>
          <div class="col-sm-9">
            <input type="text" name="first_name" id="first_name" class="form-control" placeholder="Anton"
              required="true" />
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Last name *</label>
          <div class="col-sm-9">
            <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Jerker"
              required="true" />
          </div>
        </div>
      </div>
    </div>

    <div class="row">

      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Genero *</label>
          <div class="col-sm-9">
            <select class="form-control" name="gender" id="gender" required="true">
              <option value="" selected disabled>Seleccione</option>
              <option value="Male">Masculino</option>
              <option value="Female">Femenino</option>
            </select>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Phone *</label>
          <div class="col-sm-9">
            <input type="tel" name="phone" id="phone" class="form-control" placeholder="+18099950460" required="true" />
          </div>
        </div>
      </div>
    </div>

    <br>
    <h5 style="color:#46b979;">Login information</h5>
    <div class="row">
      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Email *</label>
          <div class="col-sm-9">
            <input type="email" name="email" id="email" class="form-control" required="true"
              placeholder="Example@gmail.com" />
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Password *</label>
          <div class="col-sm-9">
            <input type="password" name="password" id="password" class="form-control" placeholder="******"
              required="true" />
          </div>
        </div>
      </div>
    </div>

    <h5 style="color:#46b979;">Operation time</h5>
    <div class="col-md-6">
      <div class="form-group">
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" name="optionsRadios" id="optionsRadios2" value="0"
              checked>
            Automatico
          </label>
        </div>
        <div class="form-check">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" name="optionsRadios" id="optionsRadios1" value="1">
            Manual
          </label>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Time star manual</label>
          <div class="col-sm-6">
            <input type="time" name="start_time" id="start_time" class="form-control" required="true" placeholder=" " />
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group row">
          <label class="col-sm-3 col-form-label">Time end manual</label>
          <div class="col-sm-6">
            <input type="time" name="end_time" id="end_time" class="form-control" placeholder=" " />
          </div>
        </div>
      </div>
    </div>

    <button type="submit" class="btn btn-primary mr-2">Create</button>
    <a href="<?php echo e(url('user/collector/data')); ?>" class="btn btn-light">Cancel</a>
    <?php echo Form::close(); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>