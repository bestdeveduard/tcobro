
<?php $__env->startSection('title'); ?>
T-Cobro Web | Agregar capital
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.capital',1)); ?></h2>

      <div class="heading-elements">

      </div>
    </div>
    <?php echo Form::open(array('url' => url('capital/store'), 'method' => 'post', 'class' => 'form-horizontal')); ?>

    <div class="panel-body">

      <div class="form-group">
        <?php echo Form::label('amount',trans_choice('general.amount',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::number('amount',null, array('class' => 'form-control touchspin', 'placeholder'=>"0.00",'required'=>'required')); ?>

        </div>
      </div>

      <div style="display: none;" class="form-group">
        <?php echo Form::label('date',trans_choice('general.date',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::date('date',date("Y-m-d"), array('class' => 'form-control date-picker',
          'placeholder'=>"",'required'=>'required')); ?>

        </div>
      </div>

      <div class="form-group">
        <?php echo Form::label('credit_account_id',trans_choice('Origen',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::select('credit_account_id',$chart,null, array('class' => 'form-control select2',
          'placeholder'=>"",'required'=>'')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('debit_account_id',trans_choice('Destino',1),array('class'=>'col-sm-3 control-label')); ?>

        <div class="col-sm-5">
          <?php echo Form::select('debit_account_id',$chart,null, array('class' => 'form-control select2',
          'placeholder'=>"",'required'=>'')); ?>

        </div>
      </div>
      <div class="form-group">
        <?php echo Form::label('notes',trans_choice('general.description',1),array('class'=>'col-sm- control-label')); ?>

        <div class="col-sm-12">
          <?php echo Form::textarea('notes',null, array('class' => 'form-control', 'rows'=>"4")); ?>

        </div>
      </div>

        <button type="submit" class="btn btn-primary pull-right"><?php echo e(trans_choice('general.save',1)); ?></button>
        <a class="btn btn-secondary" style="margin-left: 11px;" href="<?php echo e(url('capital/data')); ?>">Cancelar</a>
      
      
    </div>
    <!-- /.panel-body -->
    <div class="panel-footer">

    </div>
    <?php echo Form::close(); ?>

  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>