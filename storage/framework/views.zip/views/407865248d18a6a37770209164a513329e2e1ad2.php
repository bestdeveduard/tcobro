<?php $__env->startSection('title'); ?>
<?php echo e(trans_choice('general.user',2)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin">
  <div class="card">
    <div class="card-body">
      <h5>Crear base</h5>
      
      <?php echo Form::open(array('url' => url('baseuser/update'), 'method' => 'post', 'name' => 'form','class'=>'form-sample')); ?>


        <p class="card-description">
          <input type="hidden" name="base_id" id="base_id" value="<?php echo e($base->id); ?>"></input>
        </p>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label" align="center">Ruta: *</label>
              <div class="col-sm-9">
                <select class="form-control" name="route_id" id="route_id" required="true">
                <option value="" selected disabled>Seleccione</option>
                <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($route->id); ?>" <?php if($base->route_id == $route->id): ?> selected <?php endif; ?>><?php echo e($route->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>


          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label" align="center">Usuario: *</label>
              <div class="col-sm-9">
                <select class="form-control" name="user_id" id="user_id" required="true">
                <option value="" selected disabled>Select user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>" <?php if($base->user_id == $user->id): ?> selected <?php endif; ?>><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <label class="col-sm-3 col-form-label" align="center">Monto Base: *</label>
              <div class="col-sm-9">
                <input type="number" class="form-control" name="amount" id="amount" placeholder="$0.00" value="<?php echo e($base->amount); ?>" required="true" />
              </div>
            </div>
          </div>
        </div>

        <button type="submit" class="btn btn-primary mr-2">Crear</button>
        <a class="btn btn-secondary" href="<?php echo e(url('baseuser/data')); ?>">Cancelar</a>
      
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>