<?php $__env->startSection('title'); ?><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card panel panel-white">
  <div class="card-body">
    <div class="panel-heading">
      <h2 class="panel-title"><?php echo e(trans_choice('general.add',1)); ?> <?php echo e(trans_choice('general.repayment',1)); ?></h2>

      <div class="heading-elements">

      </div>
    </div>
    <form class="form-horizontal">
      <div class="panel-body">
        <div class="form-group">
          <?php echo Form::label('loan_id',trans_choice('general.loan',1),array('class'=>'col-sm-3 control-label')); ?>

          <div class="col-sm-5">
            <?php echo Form::select('loan_id',$loans,null, array('class' => ' form-control
            select2','placeholder'=>trans_choice('general.select',1),'required'=>'required','id'=>'loan_id')); ?>

          </div>
        </div>
      </div>
      <!-- /.panel-body -->
      <div class="panel-footer">
        <div class="heading-elements">
          <button type="submit" class="btn btn-primary pull-right"
            id="add_repayment"><?php echo e(trans_choice('general.next',1)); ?></button>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- /.box -->
<script>
$("#add_repayment").click(function(e) {
  e.preventDefault();
  if ($("#loan_id").val() === "") {
    alert("Por favor seleccione el numero de prestamo")
  } else {
    window.location = "<?php echo e(url('loan/')); ?>/" + $("#loan_id").val() + "/repayment/create";
  }
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>