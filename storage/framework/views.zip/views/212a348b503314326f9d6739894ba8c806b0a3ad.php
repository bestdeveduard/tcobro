<?php $__env->startSection('title'); ?>
T-Cobro Web|Catalogo de cuentas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <p align="right"><a href="<?php echo e(url('chart_of_account/create')); ?>" type="button" class="btn btn-primary mr-2">Crear Cuenta</a></p>  
<div class="card">
  <div class="card-body">
    <div class="panel-heading">
      <h4>Catalogo de cuentas</h4>

      <div class="heading-elements">
        <?php if(Sentinel::hasAccess('capital.create')): ?>

        <?php endif; ?>
      </div>
    </div>
    <div class="panel-body ">
      <div class="table-responsive">
        <table id="order-listing" class="table">
          <thead>
            <tr>
              <th style="width:5px";><center>Codigo</center></th>
              <th><center>Nombre</center></th>
              <th><center>Descripcion</center></th>
              <th><center>Tipo</center></th>              
              <th style="width:15px";><center>Acciones</center></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><center><?php echo e($key->gl_code); ?></center></td>
              <td><center><?php echo e($key->name); ?></center></td>
              <td><center><?php echo $key->notes; ?></center></td>              
              <td><center>
                <?php if($key->account_type=="expense"): ?>
                <?php echo e(trans_choice('general.expense',1)); ?>

                <?php endif; ?>
                <?php if($key->account_type=="asset"): ?>
                <?php echo e(trans_choice('general.asset',1)); ?>

                <?php endif; ?>
                <?php if($key->account_type=="equity"): ?>
                <?php echo e(trans_choice('general.equity',1)); ?>

                <?php endif; ?>
                <?php if($key->account_type=="liability"): ?>
                <?php echo e(trans_choice('general.liability',1)); ?>

                <?php endif; ?>
                <?php if($key->account_type=="income"): ?>
                <?php echo e(trans_choice('general.income',1)); ?>

                <?php endif; ?>
              </center></td>
              <td>
                <a href="<?php echo e(url('chart_of_account/'.$key->id.'/edit')); ?>">
                        <button style="width:110px; height:28px; background-color:#4c82c3; border-color:#4c82c3;" type="button" class="btn btn-info btn-icon-text">
                            Editar </button>               
                </a>
                <a href="<?php echo e(url('chart_of_account/'.$key->id.'/delete')); ?>">
                      <button style="width:110px; height:28px; background-color:#de3501; border-color:#de3501;"  type="button" class="btn btn-danger btn-icon-text">
                          Eliminar
                        </button>          
                </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
    <!-- /.panel-body -->
  </div>
</div>
<!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer-scripts'); ?>
<script>
$('#data-table').DataTable({
  "order": [
    [0, "asc"]
  ],
  "columnDefs": [{
    "orderable": false,
    "targets": [4]
  }],
  "language": {
    "lengthMenu": "<?php echo e(trans('general.lengthMenu')); ?>",
    "zeroRecords": "<?php echo e(trans('general.zeroRecords')); ?>",
    "info": "<?php echo e(trans('general.info')); ?>",
    "infoEmpty": "<?php echo e(trans('general.infoEmpty')); ?>",
    "search": "<?php echo e(trans('general.search')); ?>",
    "infoFiltered": "<?php echo e(trans('general.infoFiltered')); ?>",
    "paginate": {
      "first": "<?php echo e(trans('general.first')); ?>",
      "last": "<?php echo e(trans('general.last')); ?>",
      "next": "<?php echo e(trans('general.next')); ?>",
      "previous": "<?php echo e(trans('general.previous')); ?>"
    }
  },
  responsive: false
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>